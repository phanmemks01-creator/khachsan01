function checkoutHmsStay(stayId, actualCheckout) {
  return hmsWithLock_(function () {
    const stay = hmsRequire_(HMS.SHEETS.STAYS, 'MA_LUU_TRU', stayId, 'lưu trú');
    if (String(stay.TRANG_THAI || '') !== 'Đang ở') {
      const existing = hmsObjects_(HMS.SHEETS.INVOICES).filter(function (i) { return String(i.MA_LUU_TRU || '') === String(stayId) && String(i.TRANG_THAI || '') !== 'Đã hủy'; })[0];
      if (existing) return { ok: true, invoiceId: existing.MA_HOA_DON, message: 'Hồ sơ đã chuyển sang hóa đơn ' + existing.MA_HOA_DON + '.' };
      throw new Error('Hồ sơ không ở trạng thái có thể trả phòng.');
    }
    const checkIn = hmsDate_(stay.NHAN_PHONG), checkout = hmsDate_(actualCheckout) || new Date();
    if (!checkIn || checkout <= checkIn) throw new Error('Thời điểm trả phòng phải sau thời điểm nhận phòng.');
    const charge = hmsStayRoomCharge_(stay, checkout);
    const invoiceId = hmsId_(hmsSettings_().TIEN_TO_HOA_DON || 'HD');
    const pending = hmsObjects_(HMS.SHEETS.CHARGES).filter(function (x) {
      return String(x.MA_LUU_TRU || '') === String(stay.MA_LUU_TRU) && String(x.TRANG_THAI || '') === 'Đã ghi nhận' && !x.MA_HOA_DON;
    });
    const serviceTotal = pending.reduce(function (sum, x) { return sum + hmsMoney_(x.THANH_TIEN); }, 0);
    hmsAppend_(HMS.SHEETS.INVOICES, {
      MA_HOA_DON: invoiceId, NGAY_LAP: new Date(), MA_LUU_TRU: stay.MA_LUU_TRU, MA_PHONG: stay.MA_PHONG,
      TEN_KHACH: stay.TEN_KHACH, NHAN_PHONG: checkIn, TRA_PHONG: checkout, SO_DEM: charge.nights,
      DON_GIA_BINH_QUAN: charge.average, TIEN_PHONG: charge.total, TIEN_DICH_VU: serviceTotal,
      PHU_THU: hmsMoney_(stay.PHU_THU), GIAM_TIEN: 0, LY_DO_GIAM: '', PHI_DICH_VU: 0, THUE_GTGT: 0,
      TONG_THANH_TOAN: 0, TIEN_COC: hmsMoney_(stay.TIEN_COC), DA_THU_THEM: 0, DA_HOAN: 0,
      CON_PHAI_THU: 0, TIEN_THUA: 0,
      TRANG_THAI: 'Chờ thanh toán', NGAY_THANH_TOAN: '', PHUONG_THUC_CUOI: '', NGUOI_LAP: hmsUser_(), GHI_CHU: ''
    });
    const invoiceLines = [{
      MA_HOA_DON: invoiceId, LOAI_DONG: 'Tiền phòng', MA_HANG: stay.MA_PHONG,
      TEN_HANG: 'Tiền phòng ' + stay.MA_PHONG, DON_VI: 'Đêm', SO_LUONG: charge.nights,
      DON_GIA: charge.average, THANH_TIEN: charge.total, GHI_CHU: charge.note
    }].concat(pending.map(function (x) {
      return {
        MA_HOA_DON: invoiceId, LOAI_DONG: x.LOAI || 'Dịch vụ', MA_HANG: x.MA_DICH_VU,
        TEN_HANG: x.TEN_DICH_VU, DON_VI: x.DON_VI, SO_LUONG: hmsNumber_(x.SO_LUONG, 0),
        DON_GIA: hmsMoney_(x.DON_GIA), THANH_TIEN: hmsMoney_(x.THANH_TIEN), GHI_CHU: x.GHI_CHU
      };
    }));
    hmsAppendMany_(HMS.SHEETS.LINES, invoiceLines);
    hmsUpdateMany_(HMS.SHEETS.CHARGES, pending.map(function (x) {
      return { rowNumber: x._rowNumber, patch: { TRANG_THAI: 'Đã lên hóa đơn', MA_HOA_DON: invoiceId } };
    }));
    hmsUpdate_(HMS.SHEETS.STAYS, stay._rowNumber, {
      TRA_PHONG: checkout, SO_DEM: charge.nights, DON_GIA_BINH_QUAN: charge.average,
      TIEN_PHONG: charge.total, TRANG_THAI: 'Chờ thanh toán'
    });
    const booking = hmsFind_(HMS.SHEETS.BOOKINGS, 'MA_DAT_PHONG', stay.MA_DAT_PHONG);
    if (booking) hmsUpdate_(HMS.SHEETS.BOOKINGS, booking._rowNumber, { TRANG_THAI: 'Đã trả phòng' });
    const room = hmsRequire_(HMS.SHEETS.ROOMS, 'MA_PHONG', stay.MA_PHONG, 'phòng ' + stay.MA_PHONG);
    hmsUpdate_(HMS.SHEETS.ROOMS, room._rowNumber, { TRANG_THAI: 'Chờ vệ sinh' });
    hmsCreateHousekeeping_(stay.MA_PHONG, 'Vệ sinh sau trả phòng', 'Ưu tiên', 'Tự động từ trả phòng');
    hmsRecalculateInvoice_(invoiceId, {});
    hmsLog_('Trả phòng', 'Hóa đơn', invoiceId, stay.MA_PHONG + ' · ' + stay.TEN_KHACH + ' · ' + charge.nights + ' đêm');
    return { ok: true, invoiceId: invoiceId, message: 'Đã trả phòng và chuyển sang thanh toán ' + invoiceId + '.' };
  });
}

function hmsStayRoomCharge_(stay, checkout) {
  const checkIn = hmsDate_(stay.NHAN_PHONG);
  const nights = hmsNights_(checkIn, checkout);
  const moves = hmsObjects_(HMS.SHEETS.MOVES).filter(function (m) { return String(m.MA_LUU_TRU || '') === String(stay.MA_LUU_TRU); }).sort(function (a, b) { return hmsDate_(a.THOI_GIAN) - hmsDate_(b.THOI_GIAN); });
  const firstRate = moves.length ? hmsMoney_(moves[0].DON_GIA_CU) : hmsMoney_(stay.DON_GIA_BINH_QUAN);
  let total = 0;
  const detail = [];
  for (let i = 0; i < nights; i++) {
    const day = new Date(checkIn.getFullYear(), checkIn.getMonth(), checkIn.getDate() + i, 12, 0, 0, 0);
    let rate = firstRate;
    moves.forEach(function (m) { if (hmsDateKey_(m.THOI_GIAN) <= hmsDateKey_(day)) rate = hmsMoney_(m.DON_GIA_MOI); });
    if (!rate) rate = hmsResolveRate_(stay.LOAI_PHONG, day, stay.MA_GIA).price;
    total += rate;
    detail.push(hmsDateKey_(day) + ': ' + rate);
  }
  return { nights: nights, total: hmsMoney_(total), average: nights ? hmsMoney_(total / nights) : 0, note: detail.join('; ') };
}

function getHmsInvoices() {
  return hmsObjects_(HMS.SHEETS.INVOICES).map(function (r) {
    const created = hmsDate_(r.NGAY_LAP), paid = hmsDate_(r.NGAY_THANH_TOAN);
    return {
      id: String(r.MA_HOA_DON || ''), createdAt: hmsDateTimeText_(created), createdValue: created ? created.getTime() : 0,
      stayId: String(r.MA_LUU_TRU || ''), room: String(r.MA_PHONG || ''), guestName: String(r.TEN_KHACH || ''),
      checkIn: hmsDateTimeText_(r.NHAN_PHONG), checkout: hmsDateTimeText_(r.TRA_PHONG), nights: hmsNumber_(r.SO_DEM, 1),
      averageRate: hmsMoney_(r.DON_GIA_BINH_QUAN), roomAmount: hmsMoney_(r.TIEN_PHONG), serviceAmount: hmsMoney_(r.TIEN_DICH_VU),
      surcharge: hmsMoney_(r.PHU_THU), discount: hmsMoney_(r.GIAM_TIEN), discountReason: String(r.LY_DO_GIAM || ''),
      serviceFee: hmsMoney_(r.PHI_DICH_VU), vat: hmsMoney_(r.THUE_GTGT), total: hmsMoney_(r.TONG_THANH_TOAN),
      deposit: hmsMoney_(r.TIEN_COC), paidExtra: hmsMoney_(r.DA_THU_THEM), refunded: hmsMoney_(r.DA_HOAN),
      due: hmsMoney_(r.CON_PHAI_THU), credit: hmsMoney_(r.TIEN_THUA),
      status: String(r.TRANG_THAI || ''), paidAt: hmsDateTimeText_(paid), paidAtValue: paid ? paid.getTime() : 0,
      lastMethod: String(r.PHUONG_THUC_CUOI || ''), creator: String(r.NGUOI_LAP || ''), note: String(r.GHI_CHU || ''), rowNumber: r._rowNumber
    };
  }).filter(function (r) { return r.id; }).sort(function (a, b) { return b.createdValue - a.createdValue; });
}

function getHmsInvoice(invoiceId) {
  const invoice = getHmsInvoices().filter(function (x) { return x.id === String(invoiceId); })[0];
  if (!invoice) throw new Error('Không tìm thấy hóa đơn.');
  invoice.lines = hmsInvoiceLines_(invoice.id);
  invoice.receipts = getHmsReceipts(invoice.id);
  invoice.services = getHmsServices().filter(function (s) { return s.active; });
  invoice.settings = hmsSettings_();
  return invoice;
}

function hmsInvoiceLines_(invoiceId) {
  return hmsObjects_(HMS.SHEETS.LINES).filter(function (r) { return String(r.MA_HOA_DON || '') === String(invoiceId); }).map(function (r) {
    return {
      type: String(r.LOAI_DONG || ''), code: String(r.MA_HANG || ''), name: String(r.TEN_HANG || ''), unit: String(r.DON_VI || ''),
      quantity: hmsNumber_(r.SO_LUONG, 0), price: hmsMoney_(r.DON_GIA), amount: hmsMoney_(r.THANH_TIEN), note: String(r.GHI_CHU || ''), rowNumber: r._rowNumber
    };
  });
}

function getHmsReceipts(invoiceId) {
  return hmsObjects_(HMS.SHEETS.RECEIPTS).filter(function (r) { return !invoiceId || String(r.MA_HOA_DON || '') === String(invoiceId); }).map(function (r) {
    return {
      id: String(r.MA_PHIEU || ''), at: hmsDateTimeText_(r.THOI_GIAN), type: String(r.LOAI_PHIEU || ''),
      bookingId: String(r.MA_DAT_PHONG || ''), invoiceId: String(r.MA_HOA_DON || ''), room: String(r.MA_PHONG || ''),
      guestName: String(r.TEN_KHACH || ''), amount: hmsMoney_(r.SO_TIEN), method: String(r.PHUONG_THUC || ''),
      status: String(r.TRANG_THAI || ''), collector: String(r.NGUOI_THU || ''), note: String(r.GHI_CHU || '')
    };
  }).filter(function (r) { return r.id; });
}

function saveHmsInvoice(data) {
  data = data || {};
  return hmsWithLock_(function () {
    const invoice = hmsRequire_(HMS.SHEETS.INVOICES, 'MA_HOA_DON', data.invoiceId, 'hóa đơn');
    if (HMS.INVOICE_CLOSED.indexOf(String(invoice.TRANG_THAI || '')) >= 0) throw new Error('Hóa đơn đã khóa, không thể sửa.');
    if (Array.isArray(data.lines)) hmsSyncInvoiceServiceLines_(invoice, data.lines);
    const result = hmsRecalculateInvoice_(invoice.MA_HOA_DON, {
      surcharge: data.surcharge, discount: data.discount, discountReason: data.discountReason,
      serviceFeeRate: data.serviceFeeRate, vatRate: data.vatRate, note: data.note
    });
    hmsLog_('Cập nhật hóa đơn', 'Hóa đơn', invoice.MA_HOA_DON, 'Còn phải thu ' + result.due);
    return { ok: true, invoiceId: invoice.MA_HOA_DON, due: result.due, message: 'Đã cập nhật hóa đơn ' + invoice.MA_HOA_DON + '.' };
  });
}

function hmsSyncInvoiceServiceLines_(invoice, lines) {
  const existing = hmsInvoiceLines_(invoice.MA_HOA_DON).filter(function (x) { return x.type !== 'Tiền phòng'; });
  const oldQty = {}, newQty = {};
  existing.forEach(function (x) { oldQty[x.code] = (oldQty[x.code] || 0) + x.quantity; });
  const clean = lines.map(function (x) { return { code: hmsSafe_(x.code), quantity: Math.max(0, hmsNumber_(x.quantity, 0)) }; }).filter(function (x) { return x.code && x.quantity > 0; });
  clean.forEach(function (x) { newQty[x.code] = (newQty[x.code] || 0) + x.quantity; });
  const codes = Object.keys(Object.assign({}, oldQty, newQty));
  codes.forEach(function (code) {
    const service = hmsFind_(HMS.SHEETS.SERVICES, 'MA_DICH_VU', code);
    const difference = (newQty[code] || 0) - (oldQty[code] || 0);
    if (service && hmsBool_(service.THEO_DOI_TON) && difference) hmsAdjustStock_(code, -difference, 'Điều chỉnh hóa đơn', invoice.MA_LUU_TRU);
  });
  const blankUpdates = existing.map(function (x) {
    const blank = {}; HMS.HEADERS[HMS.SHEETS.LINES].forEach(function (h) { blank[h] = ''; });
    return { rowNumber: x.rowNumber, patch: blank };
  });
  hmsUpdateMany_(HMS.SHEETS.LINES, blankUpdates);
  const newLines = clean.map(function (x) {
    const service = hmsRequire_(HMS.SHEETS.SERVICES, 'MA_DICH_VU', x.code, 'dịch vụ');
    return {
      MA_HOA_DON: invoice.MA_HOA_DON, LOAI_DONG: service.LOAI, MA_HANG: service.MA_DICH_VU,
      TEN_HANG: service.TEN_DICH_VU, DON_VI: service.DON_VI, SO_LUONG: x.quantity,
      DON_GIA: hmsMoney_(service.DON_GIA), THANH_TIEN: x.quantity * hmsMoney_(service.DON_GIA), GHI_CHU: ''
    };
  });
  hmsAppendMany_(HMS.SHEETS.LINES, newLines);
}

function hmsRecalculateInvoice_(invoiceId, patch) {
  const invoice = hmsRequire_(HMS.SHEETS.INVOICES, 'MA_HOA_DON', invoiceId, 'hóa đơn');
  const lines = hmsInvoiceLines_(invoiceId);
  const serviceAmount = lines.filter(function (x) { return x.type !== 'Tiền phòng'; }).reduce(function (s, x) { return s + x.amount; }, 0);
  const roomAmount = hmsMoney_(invoice.TIEN_PHONG);
  const surcharge = patch.surcharge == null ? hmsMoney_(invoice.PHU_THU) : hmsMoney_(patch.surcharge);
  const discount = patch.discount == null ? hmsMoney_(invoice.GIAM_TIEN) : hmsMoney_(patch.discount);
  const discountReason = patch.discountReason == null ? hmsSafe_(invoice.LY_DO_GIAM) : hmsSafe_(patch.discountReason);
  if (discount > roomAmount + serviceAmount + surcharge) throw new Error('Số tiền giảm không được vượt tiền phòng, dịch vụ và phụ thu.');
  if (discount > 0 && !discountReason) throw new Error('Vui lòng nhập lý do giảm tiền.');
  const base = Math.max(0, roomAmount + serviceAmount + surcharge - discount);
  const serviceFeeRate = patch.serviceFeeRate == null || patch.serviceFeeRate === '' ? hmsPercentSetting_('PHI_DICH_VU_MAC_DINH') : Math.max(0, Math.min(1, hmsNumber_(patch.serviceFeeRate, 0)));
  const vatRate = patch.vatRate == null || patch.vatRate === '' ? hmsPercentSetting_('THUE_GTGT_MAC_DINH') : Math.max(0, Math.min(1, hmsNumber_(patch.vatRate, 0)));
  const serviceFee = hmsMoney_(base * serviceFeeRate);
  const vat = hmsMoney_((base + serviceFee) * vatRate);
  const total = hmsMoney_(base + serviceFee + vat);
  const receipts = getHmsReceipts(invoiceId).filter(function (r) { return r.status === 'Đã ghi nhận'; });
  const paidExtra = receipts.filter(function (r) { return r.type === 'Thu thanh toán'; }).reduce(function (s, r) { return s + r.amount; }, 0);
  const refunded = receipts.filter(function (r) { return r.type === 'Hoàn thanh toán'; }).reduce(function (s, r) { return s + r.amount; }, 0);
  const netPaid = hmsMoney_(invoice.TIEN_COC) + paidExtra - refunded;
  const due = Math.max(0, total - netPaid);
  const credit = Math.max(0, netPaid - total);
  hmsUpdate_(HMS.SHEETS.INVOICES, invoice._rowNumber, {
    TIEN_DICH_VU: serviceAmount, PHU_THU: surcharge, GIAM_TIEN: discount,
    LY_DO_GIAM: discountReason,
    PHI_DICH_VU: serviceFee, THUE_GTGT: vat, TONG_THANH_TOAN: total,
    DA_THU_THEM: paidExtra, DA_HOAN: refunded, CON_PHAI_THU: due, TIEN_THUA: credit,
    GHI_CHU: patch.note == null ? invoice.GHI_CHU : hmsSafe_(patch.note)
  });
  return { total: total, paidExtra: paidExtra, refunded: refunded, due: due, credit: credit };
}

function recordHmsPayment(data) {
  data = data || {};
  return hmsWithLock_(function () {
    let invoice = hmsRequire_(HMS.SHEETS.INVOICES, 'MA_HOA_DON', data.invoiceId, 'hóa đơn');
    if (String(invoice.TRANG_THAI || '') === 'Đã hủy') throw new Error('Hóa đơn đã hủy.');
    if (String(invoice.TRANG_THAI || '') === 'Đã thanh toán') return { ok: true, invoiceId: invoice.MA_HOA_DON, paid: true, message: 'Hóa đơn đã thanh toán.' };
    const before = hmsRecalculateInvoice_(invoice.MA_HOA_DON, {});
    const amount = hmsMoney_(data.amount);
    if (amount <= 0) throw new Error('Số tiền thu phải lớn hơn 0.');
    if (amount > before.due) throw new Error('Số tiền thu vượt số còn phải thu ' + before.due + '.');
    const receiptId = hmsId_('PT');
    hmsAppend_(HMS.SHEETS.RECEIPTS, {
      MA_PHIEU: receiptId, THOI_GIAN: new Date(), LOAI_PHIEU: 'Thu thanh toán', MA_DAT_PHONG: '',
      MA_HOA_DON: invoice.MA_HOA_DON, MA_PHONG: invoice.MA_PHONG, TEN_KHACH: invoice.TEN_KHACH,
      SO_TIEN: amount, PHUONG_THUC: hmsSafe_(data.method) || 'Tiền mặt', TRANG_THAI: 'Đã ghi nhận',
      NGUOI_THU: hmsUser_(), GHI_CHU: hmsSafe_(data.note)
    });
    const after = hmsRecalculateInvoice_(invoice.MA_HOA_DON, {});
    invoice = hmsRequire_(HMS.SHEETS.INVOICES, 'MA_HOA_DON', invoice.MA_HOA_DON, 'hóa đơn');
    const paid = after.due === 0;
    hmsUpdate_(HMS.SHEETS.INVOICES, invoice._rowNumber, {
      TRANG_THAI: paid ? 'Đã thanh toán' : 'Chờ thanh toán',
      NGAY_THANH_TOAN: paid ? new Date() : '', PHUONG_THUC_CUOI: hmsSafe_(data.method) || 'Tiền mặt'
    });
    if (paid) {
      const stay = hmsFind_(HMS.SHEETS.STAYS, 'MA_LUU_TRU', invoice.MA_LUU_TRU);
      if (stay) {
        hmsUpdate_(HMS.SHEETS.STAYS, stay._rowNumber, { TRANG_THAI: 'Đã trả phòng' });
        const guest = hmsFind_(HMS.SHEETS.GUESTS, 'MA_KHACH', stay.MA_KHACH);
        if (guest) hmsUpdate_(HMS.SHEETS.GUESTS, guest._rowNumber, { LAN_CUOI_LUU_TRU: stay.TRA_PHONG || new Date() });
      }
    }
    hmsLog_(paid ? 'Thanh toán đủ' : 'Thanh toán một phần', 'Hóa đơn', invoice.MA_HOA_DON, String(amount));
    return { ok: true, invoiceId: invoice.MA_HOA_DON, receiptId: receiptId, paid: paid, due: after.due, message: paid ? 'Đã thanh toán đủ hóa đơn.' : 'Đã ghi nhận thanh toán một phần.' };
  });
}

function finalizeHmsInvoice(invoiceId, method) {
  return hmsWithLock_(function () {
    const invoice = hmsRequire_(HMS.SHEETS.INVOICES, 'MA_HOA_DON', invoiceId, 'hóa đơn');
    if (String(invoice.TRANG_THAI || '') === 'Đã thanh toán') return 'Hóa đơn đã thanh toán.';
    if (String(invoice.TRANG_THAI || '') === 'Đã hủy') throw new Error('Hóa đơn đã hủy.');
    const result = hmsRecalculateInvoice_(invoiceId, {});
    if (result.due > 0) throw new Error('Hóa đơn còn phải thu ' + result.due + '.');
    if (result.credit > 0) throw new Error('Khách còn thừa ' + result.credit + '. Hãy hoàn tiền trước khi chốt hóa đơn.');
    hmsUpdate_(HMS.SHEETS.INVOICES, invoice._rowNumber, {
      TRANG_THAI: 'Đã thanh toán', NGAY_THANH_TOAN: new Date(), PHUONG_THUC_CUOI: hmsSafe_(method) || 'Tiền cọc'
    });
    const stay = hmsFind_(HMS.SHEETS.STAYS, 'MA_LUU_TRU', invoice.MA_LUU_TRU);
    if (stay) {
      hmsUpdate_(HMS.SHEETS.STAYS, stay._rowNumber, { TRANG_THAI: 'Đã trả phòng' });
      const guest = hmsFind_(HMS.SHEETS.GUESTS, 'MA_KHACH', stay.MA_KHACH);
      if (guest) hmsUpdate_(HMS.SHEETS.GUESTS, guest._rowNumber, { LAN_CUOI_LUU_TRU: stay.TRA_PHONG || new Date() });
    }
    hmsLog_('Chốt hóa đơn bằng tiền cọc', 'Hóa đơn', invoiceId, 'Còn phải thu 0');
    return 'Đã chốt thanh toán hóa đơn ' + invoiceId + '.';
  });
}

function refundHmsInvoiceCredit(data) {
  data = data || {};
  return hmsWithLock_(function () {
    const invoice = hmsRequire_(HMS.SHEETS.INVOICES, 'MA_HOA_DON', data.invoiceId, 'hóa đơn');
    if (String(invoice.TRANG_THAI || '') === 'Đã hủy') throw new Error('Hóa đơn đã hủy.');
    const before = hmsRecalculateInvoice_(invoice.MA_HOA_DON, {});
    const amount = hmsMoney_(data.amount);
    if (amount <= 0 || amount > before.credit) throw new Error('Số tiền hoàn phải lớn hơn 0 và không vượt tiền thừa ' + before.credit + '.');
    const receiptId = hmsId_('PHT');
    hmsAppend_(HMS.SHEETS.RECEIPTS, {
      MA_PHIEU: receiptId, THOI_GIAN: new Date(), LOAI_PHIEU: 'Hoàn thanh toán', MA_DAT_PHONG: '',
      MA_HOA_DON: invoice.MA_HOA_DON, MA_PHONG: invoice.MA_PHONG, TEN_KHACH: invoice.TEN_KHACH,
      SO_TIEN: amount, PHUONG_THUC: hmsSafe_(data.method) || 'Tiền mặt', TRANG_THAI: 'Đã ghi nhận',
      NGUOI_THU: hmsUser_(), GHI_CHU: hmsSafe_(data.note) || 'Hoàn tiền thừa'
    });
    const after = hmsRecalculateInvoice_(invoice.MA_HOA_DON, {});
    hmsLog_('Hoàn tiền thừa', 'Hóa đơn', invoice.MA_HOA_DON, String(amount));
    return { ok: true, invoiceId: invoice.MA_HOA_DON, receiptId: receiptId, credit: after.credit, message: 'Đã ghi nhận hoàn tiền ' + amount + '.' };
  });
}

function voidHmsInvoice(invoiceId, reason) {
  return hmsWithLock_(function () {
    const invoice = hmsRequire_(HMS.SHEETS.INVOICES, 'MA_HOA_DON', invoiceId, 'hóa đơn');
    if (String(invoice.TRANG_THAI || '') === 'Đã hủy') return 'Hóa đơn đã hủy.';
    const paid = getHmsReceipts(invoiceId).filter(function (r) { return r.type === 'Thu thanh toán' && r.status === 'Đã ghi nhận'; }).reduce(function (s, r) { return s + r.amount; }, 0);
    if (paid > 0) throw new Error('Hóa đơn đã phát sinh phiếu thu. Cần xử lý hoàn tiền trước khi hủy.');
    hmsUpdate_(HMS.SHEETS.INVOICES, invoice._rowNumber, { TRANG_THAI: 'Đã hủy', CON_PHAI_THU: 0, GHI_CHU: hmsSafe_(reason) });
    const stay = hmsFind_(HMS.SHEETS.STAYS, 'MA_LUU_TRU', invoice.MA_LUU_TRU);
    if (stay) hmsUpdate_(HMS.SHEETS.STAYS, stay._rowNumber, { TRANG_THAI: 'Đã trả phòng' });
    hmsLog_('Hủy hóa đơn', 'Hóa đơn', invoiceId, hmsSafe_(reason));
    return 'Đã hủy hóa đơn ' + invoiceId + '.';
  });
}
