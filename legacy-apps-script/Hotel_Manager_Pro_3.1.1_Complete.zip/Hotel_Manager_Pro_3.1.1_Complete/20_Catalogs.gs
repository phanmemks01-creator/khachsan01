function getHmsRooms() {
  return hmsObjects_(HMS.SHEETS.ROOMS).map(function (r) {
    return {
      code: String(r.MA_PHONG || ''), name: String(r.TEN_PHONG || ''), floor: String(r.TANG || ''),
      roomType: String(r.LOAI_PHONG || ''), capacity: Math.max(1, hmsNumber_(r.SUC_CHUA, 1)),
      status: String(r.TRANG_THAI || 'Phòng trống'), active: hmsActive_(r.HOAT_DONG),
      note: String(r.GHI_CHU || ''), rowNumber: r._rowNumber
    };
  }).filter(function (r) { return r.code; }).sort(function (a, b) { return a.code.localeCompare(b.code); });
}

function getHmsRates() {
  return hmsObjects_(HMS.SHEETS.RATES).map(function (r) {
    const from = hmsDate_(r.HIEU_LUC_TU), to = hmsDate_(r.HIEU_LUC_DEN);
    return {
      code: String(r.MA_GIA || ''), roomType: String(r.LOAI_PHONG || ''), name: String(r.TEN_BANG_GIA || ''),
      weekdayPrice: hmsMoney_(r.DON_GIA_THUONG), weekendPrice: hmsMoney_(r.DON_GIA_CUOI_TUAN || r.DON_GIA_THUONG),
      effectiveFrom: from ? hmsDateKey_(from) : '', effectiveTo: to ? hmsDateKey_(to) : '',
      active: hmsActive_(r.HOAT_DONG), priority: hmsNumber_(r.UU_TIEN, 999), rowNumber: r._rowNumber
    };
  }).filter(function (r) { return r.code; }).sort(function (a, b) { return a.priority - b.priority || a.code.localeCompare(b.code); });
}

function getHmsServices() {
  const stock = {};
  hmsObjects_(HMS.SHEETS.STOCK).forEach(function (x) { stock[String(x.MA_DICH_VU || '')] = x; });
  return hmsObjects_(HMS.SHEETS.SERVICES).map(function (r) {
    const s = stock[String(r.MA_DICH_VU || '')] || {};
    return {
      code: String(r.MA_DICH_VU || ''), type: String(r.LOAI || ''), name: String(r.TEN_DICH_VU || ''),
      unit: String(r.DON_VI || ''), price: hmsMoney_(r.DON_GIA), costPrice: hmsMoney_(r.GIA_NHAP), trackStock: hmsBool_(r.THEO_DOI_TON),
      minStock: hmsNumber_(r.TON_TOI_THIEU, 0), stock: hmsNumber_(s.TON_HIEN_TAI, 0),
      active: hmsActive_(r.HOAT_DONG), order: hmsNumber_(r.THU_TU, 999), rowNumber: r._rowNumber
    };
  }).filter(function (r) { return r.code; }).sort(function (a, b) { return a.order - b.order || a.name.localeCompare(b.name); });
}

function getHmsGuests() {
  return hmsObjects_(HMS.SHEETS.GUESTS).map(function (r) {
    return {
      id: String(r.MA_KHACH || ''), name: String(r.HO_TEN || ''), phone: String(r.SDT || ''),
      email: String(r.EMAIL || ''), identity: String(r.GIAY_TO || ''), nationality: String(r.QUOC_TICH || ''),
      address: String(r.DIA_CHI || ''), lastStay: hmsDateTimeText_(r.LAN_CUOI_LUU_TRU), note: String(r.GHI_CHU || '')
    };
  }).filter(function (r) { return r.id; });
}

function saveHmsRoom(data) {
  data = data || {};
  return hmsWithLock_(function () {
    const code = hmsSafe_(data.code).toUpperCase();
    const type = hmsSafe_(data.roomType);
    if (!code || !type) throw new Error('Vui lòng nhập mã phòng và loại phòng.');
    if (!/^[A-Z0-9_-]{1,20}$/.test(code)) throw new Error('Mã phòng chỉ gồm chữ, số, gạch ngang hoặc gạch dưới.');
    const existing = hmsFind_(HMS.SHEETS.ROOMS, 'MA_PHONG', code);
    const status = hmsSafe_(data.status) || (existing ? String(existing.TRANG_THAI || 'Phòng trống') : 'Phòng trống');
    if (HMS.ROOM_STATUSES.indexOf(status) < 0) throw new Error('Trạng thái phòng không hợp lệ.');
    hmsUpsert_(HMS.SHEETS.ROOMS, 'MA_PHONG', code, {
      MA_PHONG: code, TEN_PHONG: hmsSafe_(data.name) || ('Phòng ' + code), TANG: hmsSafe_(data.floor),
      LOAI_PHONG: type, SUC_CHUA: Math.max(1, Math.round(hmsNumber_(data.capacity, 1))), TRANG_THAI: status,
      HOAT_DONG: data.active !== false, GHI_CHU: hmsSafe_(data.note)
    });
    hmsLog_('Lưu phòng', 'Phòng', code, type + ' · ' + status);
    return 'Đã lưu phòng ' + code + '.';
  });
}

function setHmsRoomStatus(roomCode, status, note) {
  return hmsWithLock_(function () {
    const room = hmsRequire_(HMS.SHEETS.ROOMS, 'MA_PHONG', roomCode, 'phòng ' + roomCode);
    if (HMS.ROOM_STATUSES.indexOf(String(status)) < 0) throw new Error('Trạng thái phòng không hợp lệ.');
    const hasStay = hmsObjects_(HMS.SHEETS.STAYS).some(function (s) { return String(s.MA_PHONG) === String(roomCode) && String(s.TRANG_THAI) === 'Đang ở'; });
    if (hasStay && String(status) !== 'Đang ở') throw new Error('Phòng đang có khách, không thể đổi sang trạng thái này.');
    hmsUpdate_(HMS.SHEETS.ROOMS, room._rowNumber, { TRANG_THAI: status, GHI_CHU: hmsSafe_(note) || room.GHI_CHU });
    hmsLog_('Đổi trạng thái phòng', 'Phòng', roomCode, String(room.TRANG_THAI) + ' → ' + status);
    return 'Phòng ' + roomCode + ' đã chuyển sang ' + status + '.';
  });
}

function saveHmsRate(data) {
  data = data || {};
  return hmsWithLock_(function () {
    const code = hmsSafe_(data.code).toUpperCase();
    const type = hmsSafe_(data.roomType);
    if (!code || !type) throw new Error('Vui lòng nhập mã giá và loại phòng.');
    if (!/^[A-Z0-9_-]{1,30}$/.test(code)) throw new Error('Mã giá chỉ gồm chữ, số, gạch ngang hoặc gạch dưới.');
    const from = hmsDate_(data.effectiveFrom);
    const to = hmsDate_(data.effectiveTo);
    if (from && to && to < from) throw new Error('Ngày hết hiệu lực phải sau ngày bắt đầu.');
    hmsUpsert_(HMS.SHEETS.RATES, 'MA_GIA', code, {
      MA_GIA: code, LOAI_PHONG: type, TEN_BANG_GIA: hmsSafe_(data.name) || type,
      DON_GIA_THUONG: hmsMoney_(data.weekdayPrice), DON_GIA_CUOI_TUAN: hmsMoney_(data.weekendPrice || data.weekdayPrice),
      HIEU_LUC_TU: from || '', HIEU_LUC_DEN: to || '', HOAT_DONG: data.active !== false,
      UU_TIEN: hmsNumber_(data.priority, 999), CAP_NHAT_CUOI: new Date()
    });
    hmsLog_('Lưu bảng giá', 'Bảng giá', code, type);
    return 'Đã lưu bảng giá ' + code + '.';
  });
}

function saveHmsService(data) {
  data = data || {};
  return hmsWithLock_(function () {
    const code = hmsSafe_(data.code).toUpperCase();
    if (!code || !hmsSafe_(data.name)) throw new Error('Vui lòng nhập mã và tên đồ giải khát/dịch vụ.');
    if (!/^[A-Z0-9_-]{1,30}$/.test(code)) throw new Error('Mã dịch vụ chỉ gồm chữ, số, gạch ngang hoặc gạch dưới.');
    const track = hmsBool_(data.trackStock);
    hmsUpsert_(HMS.SHEETS.SERVICES, 'MA_DICH_VU', code, {
      MA_DICH_VU: code, LOAI: hmsSafe_(data.type) || 'Đồ giải khát', TEN_DICH_VU: hmsSafe_(data.name),
      DON_VI: hmsSafe_(data.unit) || 'Đơn vị', DON_GIA: hmsMoney_(data.price), THEO_DOI_TON: track,
      TON_TOI_THIEU: Math.max(0, hmsNumber_(data.minStock, 0)), HOAT_DONG: data.active !== false,
      THU_TU: hmsNumber_(data.order, 999), CAP_NHAT_CUOI: new Date(), GIA_NHAP: hmsMoney_(data.costPrice)
    });
    if (track) {
      const currentStock = hmsFind_(HMS.SHEETS.STOCK, 'MA_DICH_VU', code);
      const opening = currentStock ? hmsNumber_(currentStock.TON_DAU, 0) : hmsNumber_(data.openingStock, 0);
      const totalIn = currentStock ? hmsNumber_(currentStock.TONG_NHAP, 0) : 0;
      const totalOut = currentStock ? hmsNumber_(currentStock.TONG_XUAT, 0) : 0;
      const onHand = currentStock ? hmsNumber_(currentStock.TON_HIEN_TAI, 0) : opening;
      hmsUpsert_(HMS.SHEETS.STOCK, 'MA_DICH_VU', code, {
        MA_DICH_VU: code, TEN_HANG: hmsSafe_(data.name), DON_VI: hmsSafe_(data.unit) || 'Đơn vị',
        TON_DAU: opening, TONG_NHAP: totalIn, TONG_XUAT: totalOut,
        TON_HIEN_TAI: onHand, TON_TOI_THIEU: hmsNumber_(data.minStock, 0),
        TRANG_THAI: onHand <= hmsNumber_(data.minStock, 0) ? 'Sắp hết' : 'Đủ hàng', CAP_NHAT_CUOI: new Date()
      });
    }
    hmsLog_('Lưu dịch vụ', 'Dịch vụ', code, hmsSafe_(data.name));
    return 'Đã lưu ' + hmsSafe_(data.name) + '.';
  });
}

function hmsResolveRate_(roomType, date, rateCode) {
  const day = hmsDate_(date) || new Date();
  const key = hmsDateKey_(day);
  const allRates = getHmsRates();
  const rates = allRates.filter(function (r) {
    if (!r.active || hmsNormalize_(r.roomType) !== hmsNormalize_(roomType)) return false;
    if (rateCode && r.code !== String(rateCode)) return false;
    if (r.effectiveFrom && key < r.effectiveFrom) return false;
    if (r.effectiveTo && key > r.effectiveTo) return false;
    return true;
  });
  const rate = rates[0] || allRates.filter(function (r) { return r.active && hmsNormalize_(r.roomType) === hmsNormalize_(roomType); })[0];
  if (!rate) return { code: '', name: 'Chưa cài đặt', price: 0, weekdayPrice: 0, weekendPrice: 0 };
  const dow = day.getDay();
  return { code: rate.code, name: rate.name, price: (dow === 0 || dow === 6) ? rate.weekendPrice : rate.weekdayPrice, weekdayPrice: rate.weekdayPrice, weekendPrice: rate.weekendPrice };
}

function hmsRoomCharge_(roomType, start, end, rateCode) {
  const a = hmsDate_(start), b = hmsDate_(end);
  const nights = hmsNights_(a, b);
  let total = 0;
  for (let i = 0; i < nights; i++) {
    const day = new Date(a.getFullYear(), a.getMonth(), a.getDate() + i, 12, 0, 0, 0);
    total += hmsResolveRate_(roomType, day, rateCode).price;
  }
  return { nights: nights, total: hmsMoney_(total), average: nights ? hmsMoney_(total / nights) : 0 };
}
