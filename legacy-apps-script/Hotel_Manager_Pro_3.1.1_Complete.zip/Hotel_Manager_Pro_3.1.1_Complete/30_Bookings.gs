function getHmsBookings() {
  const rows = hmsObjects_(HMS.SHEETS.BOOKINGS).map(function (r) {
    const start = hmsDate_(r.NHAN_DU_KIEN), end = hmsDate_(r.TRA_DU_KIEN);
    const id = String(r.MA_DAT_PHONG || '');
    return {
      id: id, groupId: String(r.MA_NHOM_DAT || id), createdAt: hmsDateTimeText_(r.NGAY_TAO),
      arrival: hmsDateTimeInput_(start), departure: hmsDateTimeInput_(end),
      arrivalValue: start ? start.getTime() : 0, departureValue: end ? end.getTime() : 0,
      nights: hmsNumber_(r.SO_DEM_DU_KIEN, start && end ? hmsNights_(start, end) : 0),
      room: String(r.MA_PHONG || ''), roomType: String(r.LOAI_PHONG || ''), rateCode: String(r.MA_GIA || ''),
      expectedRate: hmsMoney_(r.DON_GIA_DU_KIEN), guestId: String(r.MA_KHACH || ''), guestName: String(r.TEN_KHACH || ''),
      phone: String(r.SDT || ''), guestCount: hmsNumber_(r.SO_NGUOI, 1), deposit: hmsMoney_(r.TIEN_COC),
      status: String(r.TRANG_THAI || ''), channel: String(r.KENH_DAT || ''), creator: String(r.NGUOI_TAO || ''),
      note: String(r.GHI_CHU || ''), rowNumber: r._rowNumber
    };
  }).filter(function (r) { return r.id; });
  const groupCounts = {};
  rows.forEach(function (row) { groupCounts[row.groupId] = (groupCounts[row.groupId] || 0) + 1; });
  return rows.map(function (row) {
    row.groupRoomCount = groupCounts[row.groupId] || 1;
    return row;
  }).sort(function (a, b) { return b.arrivalValue - a.arrivalValue; });
}

function getHmsAvailability(fromDate, toDate, excludeBookingId) {
  return getHmsAvailabilityBoard(fromDate, toDate, excludeBookingId).rooms.filter(function (room) { return room.canBook; });
}

/**
 * Bảng phòng trực quan dùng cho màn hình Đặt phòng.
 * Đọc dữ liệu đặt phòng/lưu trú hiện có một lần rồi phân loại toàn bộ phòng,
 * giúp giao diện gõ - lọc - chọn nhanh mà không gọi máy chủ theo từng phòng.
 */
function getHmsAvailabilityBoard(fromDate, toDate, excludeBookingId) {
  const start = hmsDate_(fromDate), end = hmsDate_(toDate);
  if (!start || !end || end <= start) throw new Error('Khoảng thời gian tìm phòng không hợp lệ.');
  const startMs = start.getTime(), endMs = end.getTime();
  const rooms = getHmsRooms().filter(function (room) { return room.active; });
  const bookings = getHmsBookings().filter(function (booking) {
    return String(booking.id) !== String(excludeBookingId || '') &&
      HMS.BOOKING_CLOSED.indexOf(booking.status) < 0 && booking.status !== 'Đã nhận phòng';
  });
  const stays = getHmsStays().filter(function (stay) { return stay.status === 'Đang ở'; });
  const rates = getHmsRates();
  const bookingsByRoom = {}, staysByRoom = {};
  bookings.forEach(function (booking) {
    if (!bookingsByRoom[booking.room]) bookingsByRoom[booking.room] = [];
    bookingsByRoom[booking.room].push(booking);
  });
  Object.keys(bookingsByRoom).forEach(function (roomCode) {
    bookingsByRoom[roomCode].sort(function (a, b) { return a.arrivalValue - b.arrivalValue; });
  });
  stays.forEach(function (stay) {
    if (!staysByRoom[stay.room]) staysByRoom[stay.room] = [];
    staysByRoom[stay.room].push(stay);
  });
  const boardRooms = rooms.map(function (room) {
    const roomBookings = bookingsByRoom[room.code] || [], roomStays = staysByRoom[room.code] || [];
    const booking = roomBookings.filter(function (item) {
      return item.arrivalValue && item.departureValue &&
        hmsIntervalsOverlap_(item.arrivalValue, item.departureValue, startMs, endMs);
    })[0] || null;
    const stay = roomStays.filter(function (item) {
      const stayEnd = item.expectedCheckoutValue || Number.MAX_SAFE_INTEGER;
      return item.checkInValue &&
        hmsIntervalsOverlap_(item.checkInValue, stayEnd, startMs, endMs);
    })[0] || null;
    const nextBooking = roomBookings.filter(function (item) { return item.arrivalValue >= startMs; })[0] || null;
    const rate = hmsResolveBoardRate_(rates, room.roomType, start);
    let canBook = true, category = 'AVAILABLE', label = 'Phòng trống';
    let note = 'Không có đặt phòng hoặc lượt lưu trú trùng thời gian đã chọn.';
    if (['Bảo trì', 'Tạm khóa'].indexOf(room.status) >= 0) {
      canBook = false; category = 'BLOCKED'; label = room.status;
      note = 'Phòng đang bảo trì hoặc tạm khóa, chưa thể nhận khách.';
    } else if (room.status === 'Chờ vệ sinh') {
      canBook = false; category = 'CLEANING'; label = 'Chờ vệ sinh';
      note = 'Cần hoàn tất vệ sinh và mở lại phòng trước khi nhận khách.';
    } else if (stay) {
      canBook = false; category = 'OCCUPIED'; label = 'Đang có khách';
      note = 'Lượt lưu trú ' + stay.id + ' dự kiến trả ' + (stay.expectedCheckoutText || 'chưa xác định') + '.';
    } else if (booking) {
      canBook = false; category = 'RESERVED'; label = 'Đã có lịch đặt';
      note = 'Phiếu ' + booking.id + ' từ ' + booking.arrival.replace('T', ' ') + ' đến ' + booking.departure.replace('T', ' ') + '.';
    } else if (room.status === 'Đang ở' || room.status === 'Đã đặt') {
      category = 'EXPECTED_AVAILABLE'; label = 'Dự kiến sẽ trống';
      note = 'Không trùng khoảng đã chọn; cần xác nhận phòng đã trả và vệ sinh xong trước khi nhận khách.';
    }
    return {
      code: room.code, name: room.name, floor: room.floor, roomType: room.roomType,
      capacity: room.capacity, roomStatus: room.status, rateCode: rate.code, rate: rate.price,
      canBook: canBook, category: category, label: label, note: note,
      nextBookingId: nextBooking ? nextBooking.id : '',
      nextBookingAt: nextBooking ? nextBooking.arrival.replace('T', ' ') : ''
    };
  });
  const available = boardRooms.filter(function (room) { return room.canBook; });
  const summary = {
    totalRooms: boardRooms.length,
    availableRooms: available.length,
    occupiedRooms: boardRooms.filter(function (room) { return room.category === 'OCCUPIED'; }).length,
    reservedRooms: boardRooms.filter(function (room) { return room.category === 'RESERVED'; }).length,
    blockedRooms: boardRooms.filter(function (room) { return ['BLOCKED', 'CLEANING'].indexOf(room.category) >= 0; }).length
  };
  const names = available.slice(0, 15).map(function (room) { return room.code; });
  const shareText = 'Từ ' + hmsDateTimeText_(start) + ' đến ' + hmsDateTimeText_(end) +
    ': còn ' + available.length + '/' + boardRooms.length + ' phòng phù hợp.' +
    (names.length ? ' Phòng: ' + names.join(', ') + (available.length > names.length ? ', ...' : '') + '.' : '');
  return { from: hmsDateTimeInput_(start), to: hmsDateTimeInput_(end), summary: summary, rooms: boardRooms, shareText: shareText };
}

function hmsResolveBoardRate_(rates, roomType, date) {
  const day = hmsDate_(date) || new Date(), key = hmsDateKey_(day);
  const matching = rates.filter(function (rate) {
    if (!rate.active || hmsNormalize_(rate.roomType) !== hmsNormalize_(roomType)) return false;
    if (rate.effectiveFrom && key < rate.effectiveFrom) return false;
    if (rate.effectiveTo && key > rate.effectiveTo) return false;
    return true;
  });
  const rate = matching[0] || rates.filter(function (item) {
    return item.active && hmsNormalize_(item.roomType) === hmsNormalize_(roomType);
  })[0];
  if (!rate) return { code: '', price: 0 };
  const dow = day.getDay();
  return { code: rate.code, price: (dow === 0 || dow === 6) ? rate.weekendPrice : rate.weekdayPrice };
}

function saveHmsBooking(data) {
  return hmsWithLock_(function () { return hmsSaveBooking_(data || {}); });
}

/**
 * Một khách/đoàn có thể đặt nhiều phòng trong một thao tác. Mỗi phòng vẫn là
 * một phiếu độc lập để nhận phòng, trả phòng và lập hóa đơn riêng; MA_NHOM_DAT
 * liên kết các phiếu và tổng tiền cọc chỉ được phân bổ một lần.
 */
function saveHmsGroupBooking(data) {
  return hmsWithLock_(function () { return hmsSaveGroupBooking_(data || {}); });
}

function hmsSaveGroupBooking_(data) {
  if (hmsSafe_(data.id)) throw new Error('Khi sửa phiếu, vui lòng sửa từng phòng riêng để giữ đúng lịch sử nghiệp vụ.');
  const requested = Array.isArray(data.rooms) ? data.rooms : [];
  if (!requested.length && data.room) requested.push({ room: data.room, guestCount: data.guestCount, rateCode: data.rateCode });
  if (!requested.length) throw new Error('Vui lòng chọn ít nhất một phòng.');
  if (requested.length > 30) throw new Error('Mỗi lần chỉ được đặt tối đa 30 phòng.');

  const unique = {}, start = hmsDate_(data.arrival), end = hmsDate_(data.departure);
  const guestName = hmsSafe_(data.guestName);
  if (!guestName || !start || !end) throw new Error('Vui lòng nhập tên khách, ngày nhận và ngày trả dự kiến.');
  if (end <= start) throw new Error('Ngày trả dự kiến phải sau ngày nhận phòng.');
  const entries = requested.map(function (item) {
    item = (item && typeof item === 'object') ? item : { room: item };
    const roomCode = hmsSafe_(item.room || item.code).toUpperCase();
    if (!roomCode) throw new Error('Danh sách có phòng chưa hợp lệ.');
    if (unique[roomCode]) throw new Error('Phòng ' + roomCode + ' bị chọn trùng.');
    unique[roomCode] = true;
    const room = hmsRequire_(HMS.SHEETS.ROOMS, 'MA_PHONG', roomCode, 'phòng ' + roomCode);
    if (!hmsActive_(room.HOAT_DONG)) throw new Error('Phòng ' + roomCode + ' đã ngừng hoạt động.');
    if (['Bảo trì', 'Tạm khóa', 'Chờ vệ sinh'].indexOf(String(room.TRANG_THAI || '')) >= 0) throw new Error('Phòng ' + roomCode + ' chưa sẵn sàng để đặt.');
    const guestCount = Math.max(1, Math.round(hmsNumber_(item.guestCount, data.guestCount || 1)));
    if (guestCount > hmsNumber_(room.SUC_CHUA, 1)) throw new Error('Số khách của phòng ' + roomCode + ' vượt sức chứa.');
    hmsAssertRoomAvailable_(roomCode, start, end, '', '');
    const rate = hmsResolveRate_(room.LOAI_PHONG, start, requested.length === 1 ? hmsSafe_(item.rateCode || data.rateCode) : '');
    if (!rate.code || rate.price <= 0) throw new Error('Chưa có bảng giá hợp lệ cho phòng ' + roomCode + '.');
    return { roomCode: roomCode, guestCount: guestCount, rateCode: rate.code, weight: Math.max(1, rate.price) };
  });

  const groupId = hmsSafe_(data.groupId) || hmsId_('NDP');
  const guestId = hmsUpsertGuest_(data, hmsSafe_(data.guestId));
  const deposits = hmsAllocateGroupDeposit_(hmsMoney_(data.deposit), entries.map(function (entry) { return entry.weight; }));
  const ids = entries.map(function (entry, index) {
    const payload = Object.assign({}, data, {
      id: '', groupId: groupId, guestId: guestId, room: entry.roomCode,
      guestCount: entry.guestCount, rateCode: entry.rateCode, deposit: deposits[index],
      _knownNew: true, _prevalidated: true, _guestValidated: true, _deferRoomRefresh: true
    });
    return hmsSaveBooking_(payload).id;
  });
  hmsRefreshRoomStatuses_(entries.map(function (entry) { return entry.roomCode; }));
  hmsLog_('Tạo nhóm đặt phòng', 'Nhóm đặt phòng', groupId, guestName + ' · ' + entries.map(function (entry) { return entry.roomCode; }).join(', '));
  return { ok: true, groupId: groupId, ids: ids, count: ids.length, message: 'Đã tạo ' + ids.length + ' phiếu đặt phòng cho ' + guestName + '.' };
}

function hmsAllocateGroupDeposit_(total, weights) {
  total = hmsMoney_(total);
  const sum = weights.reduce(function (value, weight) { return value + Math.max(0, Number(weight || 0)); }, 0) || weights.length;
  let allocated = 0;
  return weights.map(function (weight, index) {
    if (index === weights.length - 1) return Math.max(0, total - allocated);
    const amount = Math.floor(total * (Math.max(0, Number(weight || 0)) || 1) / sum);
    allocated += amount;
    return amount;
  });
}

function hmsSaveBooking_(data) {
  const id = hmsSafe_(data.id) || hmsId_(hmsSettings_().TIEN_TO_DAT_PHONG || 'DP');
  const old = data._knownNew ? null : hmsFind_(HMS.SHEETS.BOOKINGS, 'MA_DAT_PHONG', id);
  if (old && ['Đã nhận phòng', 'Đã trả phòng'].indexOf(String(old.TRANG_THAI || '')) >= 0) throw new Error('Phiếu đã nhận/trả phòng, không thể sửa tại đây.');
  const roomCode = hmsSafe_(data.room).toUpperCase();
  const guestName = hmsSafe_(data.guestName);
  const start = hmsDate_(data.arrival), end = hmsDate_(data.departure);
  if (!roomCode || !guestName || !start || !end) throw new Error('Vui lòng nhập đủ phòng, tên khách, ngày nhận và ngày trả dự kiến.');
  if (end <= start) throw new Error('Ngày trả dự kiến phải sau ngày nhận phòng.');
  const room = hmsRequire_(HMS.SHEETS.ROOMS, 'MA_PHONG', roomCode, 'phòng ' + roomCode);
  if (!hmsActive_(room.HOAT_DONG)) throw new Error('Phòng đã ngừng hoạt động.');
  if (['Bảo trì', 'Tạm khóa'].indexOf(String(room.TRANG_THAI || '')) >= 0) throw new Error('Phòng đang bảo trì hoặc tạm khóa.');
  const count = Math.max(1, Math.round(hmsNumber_(data.guestCount, 1)));
  if (count > hmsNumber_(room.SUC_CHUA, 1)) throw new Error('Số khách vượt sức chứa của phòng.');
  if (!data._prevalidated) hmsAssertRoomAvailable_(roomCode, start, end, id, '');
  const rate = hmsResolveRate_(room.LOAI_PHONG, start, hmsSafe_(data.rateCode));
  if (!rate.code || rate.price <= 0) throw new Error('Chưa có bảng giá hợp lệ cho loại phòng này.');
  const guestId = data._guestValidated ? hmsSafe_(data.guestId) : hmsUpsertGuest_(data, hmsSafe_(data.guestId) || (old ? old.MA_KHACH : ''));
  if (!guestId) throw new Error('Không xác định được mã khách hàng.');
  const deposit = hmsMoney_(data.deposit);
  if (old && deposit < hmsMoney_(old.TIEN_COC)) throw new Error('Không giảm tiền cọc bằng cách sửa phiếu. Hãy dùng nghiệp vụ hoàn cọc để giữ đúng lịch sử tài chính.');
  const bookingObject = {
    MA_DAT_PHONG: id, NGAY_TAO: old ? old.NGAY_TAO : new Date(), NHAN_DU_KIEN: start, TRA_DU_KIEN: end,
    SO_DEM_DU_KIEN: hmsNights_(start, end), MA_PHONG: roomCode, LOAI_PHONG: room.LOAI_PHONG,
    MA_GIA: rate.code, DON_GIA_DU_KIEN: rate.price, MA_KHACH: guestId, TEN_KHACH: guestName,
    SDT: hmsSafe_(data.phone), SO_NGUOI: count, TIEN_COC: deposit,
    TRANG_THAI: hmsSafe_(data.status) || (old ? old.TRANG_THAI : 'Đã xác nhận'),
    KENH_DAT: hmsSafe_(data.channel) || 'Trực tiếp', NGUOI_TAO: old ? old.NGUOI_TAO : hmsUser_(), GHI_CHU: hmsSafe_(data.note),
    MA_NHOM_DAT: hmsSafe_(data.groupId) || (old ? hmsSafe_(old.MA_NHOM_DAT) : '') || id
  };
  if (old) hmsUpdate_(HMS.SHEETS.BOOKINGS, old._rowNumber, bookingObject);
  else hmsAppend_(HMS.SHEETS.BOOKINGS, bookingObject);
  hmsSyncBookingDeposit_(id, old ? hmsMoney_(old.TIEN_COC) : 0, deposit, roomCode, guestName, hmsSafe_(data.paymentMethod) || 'Tiền mặt');
  if (!data._deferRoomRefresh) {
    const roomCodes = [roomCode];
    if (old && String(old.MA_PHONG || '') !== roomCode) roomCodes.push(String(old.MA_PHONG || ''));
    hmsRefreshRoomStatuses_(roomCodes);
  }
  hmsLog_(old ? 'Sửa đặt phòng' : 'Tạo đặt phòng', 'Đặt phòng', id, roomCode + ' · ' + guestName);
  return { ok: true, id: id, groupId: hmsSafe_(data.groupId) || (old ? hmsSafe_(old.MA_NHOM_DAT) : '') || id, message: 'Đã lưu đặt phòng ' + roomCode + ' cho ' + guestName + '.' };
}

function hmsUpsertGuest_(data, existingId) {
  const phone = hmsSafe_(data.phone);
  let guest = existingId ? hmsFind_(HMS.SHEETS.GUESTS, 'MA_KHACH', existingId) : null;
  if (!guest && phone) guest = hmsObjects_(HMS.SHEETS.GUESTS).filter(function (g) { return hmsSafe_(g.SDT) === phone; })[0] || null;
  const id = guest ? String(guest.MA_KHACH) : hmsId_('KH');
  hmsUpsert_(HMS.SHEETS.GUESTS, 'MA_KHACH', id, {
    MA_KHACH: id, HO_TEN: hmsSafe_(data.guestName), SDT: phone, EMAIL: hmsSafe_(data.email),
    GIAY_TO: hmsSafe_(data.identity), QUOC_TICH: hmsSafe_(data.nationality), DIA_CHI: hmsSafe_(data.address),
    LAN_CUOI_LUU_TRU: guest ? guest.LAN_CUOI_LUU_TRU : '', GHI_CHU: hmsSafe_(data.guestNote)
  });
  return id;
}

function hmsSyncBookingDeposit_(bookingId, oldAmount, newAmount, room, guest, method) {
  const difference = hmsMoney_(newAmount) - hmsMoney_(oldAmount);
  if (!difference) return;
  hmsAppend_(HMS.SHEETS.RECEIPTS, {
    MA_PHIEU: hmsId_(difference > 0 ? 'PTC' : 'PHC'), THOI_GIAN: new Date(),
    LOAI_PHIEU: difference > 0 ? 'Thu tiền cọc' : 'Hoàn tiền cọc', MA_DAT_PHONG: bookingId, MA_HOA_DON: '',
    MA_PHONG: room, TEN_KHACH: guest, SO_TIEN: Math.abs(difference), PHUONG_THUC: method,
    TRANG_THAI: 'Đã ghi nhận', NGUOI_THU: hmsUser_(), GHI_CHU: 'Điều chỉnh tiền cọc'
  });
}

function checkInHmsBooking(bookingId, actualCheckIn) {
  return hmsWithLock_(function () { return hmsCheckInBooking_(bookingId, actualCheckIn); });
}

function hmsCheckInBooking_(bookingId, actualCheckIn) {
  const b = hmsRequire_(HMS.SHEETS.BOOKINGS, 'MA_DAT_PHONG', bookingId, 'phiếu đặt phòng');
  if (['Đã hủy', 'Không đến', 'Đã trả phòng', 'Đã nhận phòng'].indexOf(String(b.TRANG_THAI || '')) >= 0) throw new Error('Phiếu không ở trạng thái có thể nhận phòng.');
  const room = hmsRequire_(HMS.SHEETS.ROOMS, 'MA_PHONG', b.MA_PHONG, 'phòng ' + b.MA_PHONG);
  if (['Đang ở', 'Chờ vệ sinh', 'Bảo trì', 'Tạm khóa'].indexOf(String(room.TRANG_THAI || '')) >= 0) throw new Error('Phòng chưa sẵn sàng nhận khách.');
  const checkIn = hmsDate_(actualCheckIn) || new Date();
  const expectedOut = hmsDate_(b.TRA_DU_KIEN);
  hmsAssertRoomAvailable_(b.MA_PHONG, checkIn, expectedOut, b.MA_DAT_PHONG, '');
  const stayId = hmsId_('LT');
  const rate = hmsResolveRate_(b.LOAI_PHONG, checkIn, b.MA_GIA);
  hmsAppend_(HMS.SHEETS.STAYS, {
    MA_LUU_TRU: stayId, MA_DAT_PHONG: b.MA_DAT_PHONG, MA_PHONG: b.MA_PHONG, LOAI_PHONG: b.LOAI_PHONG,
    MA_GIA: b.MA_GIA || rate.code, MA_KHACH: b.MA_KHACH, TEN_KHACH: b.TEN_KHACH, SDT: b.SDT,
    SO_NGUOI: b.SO_NGUOI, NHAN_PHONG: checkIn, TRA_DU_KIEN: expectedOut, TRA_PHONG: '', SO_DEM: '',
    DON_GIA_BINH_QUAN: rate.price, TIEN_PHONG: 0, PHU_THU: 0, TIEN_COC: hmsMoney_(b.TIEN_COC),
    TRANG_THAI: 'Đang ở', NGUOI_NHAN: hmsUser_(), GHI_CHU: b.GHI_CHU
  });
  hmsUpdate_(HMS.SHEETS.BOOKINGS, b._rowNumber, { TRANG_THAI: 'Đã nhận phòng' });
  hmsUpdate_(HMS.SHEETS.ROOMS, room._rowNumber, { TRANG_THAI: 'Đang ở' });
  hmsLog_('Nhận phòng', 'Lưu trú', stayId, b.MA_PHONG + ' · ' + b.TEN_KHACH);
  return { ok: true, stayId: stayId, message: 'Đã nhận phòng ' + b.MA_PHONG + ' cho ' + b.TEN_KHACH + '.' };
}

function createHmsWalkIn(data) {
  return hmsWithLock_(function () {
    data = data || {};
    data.status = 'Đã xác nhận';
    const booking = hmsSaveBooking_(data);
    return hmsCheckInBooking_(booking.id, data.actualCheckIn || data.arrival);
  });
}

function createHmsGroupWalkIn(data) {
  return hmsWithLock_(function () {
    data = data || {};
    data.status = 'Đã xác nhận';
    const group = hmsSaveGroupBooking_(data);
    const stays = group.ids.map(function (bookingId) {
      return hmsCheckInBooking_(bookingId, data.actualCheckIn || data.arrival).stayId;
    });
    return { ok: true, groupId: group.groupId, bookingIds: group.ids, stayIds: stays, message: 'Đã mở ' + stays.length + ' phòng cho ' + hmsSafe_(data.guestName) + '.' };
  });
}

function cancelHmsBooking(bookingId, refundDeposit) {
  return hmsWithLock_(function () {
    const b = hmsRequire_(HMS.SHEETS.BOOKINGS, 'MA_DAT_PHONG', bookingId, 'phiếu đặt phòng');
    if (['Đã nhận phòng', 'Đã trả phòng'].indexOf(String(b.TRANG_THAI || '')) >= 0) throw new Error('Phiếu đã nhận/trả phòng, không thể hủy.');
    if (String(b.TRANG_THAI || '') === 'Đã hủy') return 'Phiếu đã được hủy trước đó.';
    hmsUpdate_(HMS.SHEETS.BOOKINGS, b._rowNumber, { TRANG_THAI: 'Đã hủy' });
    if (refundDeposit && hmsMoney_(b.TIEN_COC) > 0) {
      hmsAppend_(HMS.SHEETS.RECEIPTS, {
        MA_PHIEU: hmsId_('PHC'), THOI_GIAN: new Date(), LOAI_PHIEU: 'Hoàn tiền cọc', MA_DAT_PHONG: b.MA_DAT_PHONG,
        MA_HOA_DON: '', MA_PHONG: b.MA_PHONG, TEN_KHACH: b.TEN_KHACH, SO_TIEN: hmsMoney_(b.TIEN_COC),
        PHUONG_THUC: 'Theo phương thức ban đầu', TRANG_THAI: 'Đã ghi nhận', NGUOI_THU: hmsUser_(), GHI_CHU: 'Hủy đặt phòng'
      });
    }
    hmsRefreshRoomStatus_(b.MA_PHONG);
    hmsLog_('Hủy đặt phòng', 'Đặt phòng', b.MA_DAT_PHONG, b.MA_PHONG + ' · ' + b.TEN_KHACH);
    return 'Đã hủy phiếu ' + b.MA_DAT_PHONG + '.';
  });
}
