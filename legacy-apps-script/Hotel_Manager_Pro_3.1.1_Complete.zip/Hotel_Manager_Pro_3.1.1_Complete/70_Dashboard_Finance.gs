function getHmsBootstrap() {
  hmsEnsureBootstrapReady_();
  const rooms = getHmsRooms();
  const bookings = getHmsBookings().slice(0, 500);
  const stays = getHmsStays().slice(0, 500);
  const invoices = getHmsInvoices().slice(0, 500);
  const charges = getHmsCharges('').slice(0, 500);
  const housekeeping = getHmsHousekeeping().slice(0, 300);
  const maintenance = getHmsMaintenance().slice(0, 300);
  return {
    version: HMS.VERSION, generatedAt: hmsDateTimeText_(new Date()), settings: hmsSettings_(), financeSecurity: getHmsFinanceStatus(),
    rooms: rooms, rates: getHmsRates(), services: getHmsServices(), bookings: bookings, stays: stays,
    invoices: invoices, charges: charges, housekeeping: housekeeping, maintenance: maintenance,
    dashboard: hmsDashboardFrom_(rooms, bookings, stays, invoices, housekeeping, maintenance)
  };
}

function getHmsBootstrapSafe() {
  try {
    const data = getHmsBootstrap();
    if (!data || typeof data !== 'object') throw new Error('Máy chủ không tạo được dữ liệu khởi động.');
    return hmsJsonSafe_({ ok: true, data: data });
  } catch (error) {
    return hmsJsonSafe_({ ok: false, error: String(error && error.message ? error.message : error || 'Không tải được dữ liệu.') });
  }
}

function getHmsDashboard() {
  const rooms = getHmsRooms(), bookings = getHmsBookings(), stays = getHmsStays(), invoices = getHmsInvoices();
  return hmsDashboardFrom_(rooms, bookings, stays, invoices, getHmsHousekeeping(), getHmsMaintenance());
}

function hmsDashboardFrom_(rooms, bookings, stays, invoices, housekeeping, maintenance) {
  const activeRooms = rooms.filter(function (r) { return r.active; });
  const monthStart = new Date(); monthStart.setDate(1); monthStart.setHours(0, 0, 0, 0);
  const paidMonth = invoices.filter(function (i) { return i.status === 'Đã thanh toán' && i.paidAtValue >= monthStart.getTime(); });
  const occupied = activeRooms.filter(function (r) { return r.status === 'Đang ở'; }).length;
  return {
    totalRooms: activeRooms.length,
    available: activeRooms.filter(function (r) { return r.status === 'Phòng trống'; }).length,
    booked: activeRooms.filter(function (r) { return r.status === 'Đã đặt'; }).length,
    occupied: occupied,
    cleaning: activeRooms.filter(function (r) { return r.status === 'Chờ vệ sinh'; }).length,
    maintenance: activeRooms.filter(function (r) { return ['Bảo trì', 'Tạm khóa'].indexOf(r.status) >= 0; }).length,
    occupancyRate: activeRooms.length ? occupied / activeRooms.length : 0,
    arrivalsToday: bookings.filter(function (b) { return ['Chờ xác nhận', 'Đã xác nhận'].indexOf(b.status) >= 0 && hmsDateKey_(b.arrival) === hmsDateKey_(new Date()); }).length,
    departuresToday: stays.filter(function (s) { return s.status === 'Đang ở' && hmsDateKey_(s.expectedCheckout) === hmsDateKey_(new Date()); }).length,
    pendingInvoices: invoices.filter(function (i) { return i.status === 'Chờ thanh toán'; }).length,
    outstanding: invoices.filter(function (i) { return i.status === 'Chờ thanh toán'; }).reduce(function (sum, i) { return sum + i.due; }, 0),
    monthRevenue: paidMonth.reduce(function (sum, i) { return sum + i.total; }, 0),
    openHousekeeping: housekeeping.filter(function (x) { return ['Chờ xử lý', 'Đang làm'].indexOf(x.status) >= 0; }).length,
    openMaintenance: maintenance.filter(function (x) { return ['Chờ xử lý', 'Đang xử lý'].indexOf(x.status) >= 0; }).length
  };
}

function getHmsFinanceReport(fromDate, toDate, financeToken) {
  hmsRequireFinanceToken_(financeToken);
  const start = fromDate ? hmsStartDay_(fromDate).getTime() : 0;
  const end = toDate ? hmsEndDay_(toDate).getTime() : Number.MAX_SAFE_INTEGER;
  const paidInvoices = getHmsInvoices().filter(function (i) { return i.status === 'Đã thanh toán' && i.paidAtValue >= start && i.paidAtValue <= end; });
  const receiptRows = hmsObjects_(HMS.SHEETS.RECEIPTS).map(function (r) {
    const at = hmsDate_(r.THOI_GIAN);
    return {
      id: String(r.MA_PHIEU || ''), at: hmsDateTimeText_(at), atValue: at ? at.getTime() : 0,
      type: String(r.LOAI_PHIEU || ''), invoiceId: String(r.MA_HOA_DON || ''), room: String(r.MA_PHONG || ''),
      guestName: String(r.TEN_KHACH || ''), amount: hmsMoney_(r.SO_TIEN), method: String(r.PHUONG_THUC || ''),
      status: String(r.TRANG_THAI || ''), collector: String(r.NGUOI_THU || '')
    };
  }).filter(function (r) { return r.id && r.status === 'Đã ghi nhận' && r.atValue >= start && r.atValue <= end; });
  const cashReceived = receiptRows.reduce(function (sum, r) {
    return sum + (r.type.indexOf('Hoàn') === 0 ? -r.amount : r.amount);
  }, 0);
  const methods = {};
  receiptRows.forEach(function (r) {
    const sign = r.type.indexOf('Hoàn') === 0 ? -1 : 1;
    methods[r.method || 'Khác'] = (methods[r.method || 'Khác'] || 0) + sign * r.amount;
  });
  const outstandingInvoices = getHmsInvoices().filter(function (i) { return i.status === 'Chờ thanh toán' && i.due > 0; });
  const paidIds = {};
  paidInvoices.forEach(function (i) { paidIds[i.id] = true; });
  const serviceTypes = {};
  getHmsServices().forEach(function (s) { serviceTypes[s.code] = s.type; });
  const beverageRevenue = hmsObjects_(HMS.SHEETS.LINES).filter(function (r) {
    const type = hmsNormalize_(serviceTypes[String(r.MA_HANG || '')] || '');
    return paidIds[String(r.MA_HOA_DON || '')] && (type === 'DO GIAI KHAT' || type === 'NUOC UONG');
  }).reduce(function (sum, r) { return sum + hmsMoney_(r.THANH_TIEN); }, 0);
  const byDay = {};
  const byRoom = {};
  const byRoomType = {};
  const roomTypes = {};
  getHmsRooms().forEach(function (r) { roomTypes[r.code] = r.roomType; });
  paidInvoices.forEach(function (i) {
    const key = hmsDateKey_(i.paidAtValue);
    byDay[key] = (byDay[key] || 0) + i.total;
    byRoom[i.room || 'Không xác định'] = (byRoom[i.room || 'Không xác định'] || 0) + i.total;
    const roomType = roomTypes[i.room] || 'Không xác định';
    byRoomType[roomType] = (byRoomType[roomType] || 0) + i.total;
  });
  return {
    fromDate: fromDate || '', toDate: toDate || '', invoiceCount: paidInvoices.length,
    revenue: paidInvoices.reduce(function (s, i) { return s + i.total; }, 0),
    roomRevenue: paidInvoices.reduce(function (s, i) { return s + i.roomAmount; }, 0),
    serviceRevenue: paidInvoices.reduce(function (s, i) { return s + i.serviceAmount; }, 0),
    beverageRevenue: beverageRevenue,
    surchargeRevenue: paidInvoices.reduce(function (s, i) { return s + i.surcharge; }, 0),
    discounts: paidInvoices.reduce(function (s, i) { return s + i.discount; }, 0),
    serviceFees: paidInvoices.reduce(function (s, i) { return s + i.serviceFee; }, 0),
    vat: paidInvoices.reduce(function (s, i) { return s + i.vat; }, 0),
    cashReceived: cashReceived,
    outstanding: outstandingInvoices.reduce(function (s, i) { return s + i.due; }, 0),
    invoices: paidInvoices,
    receipts: receiptRows.sort(function (a, b) { return b.atValue - a.atValue; }),
    outstandingInvoices: outstandingInvoices,
    byDay: Object.keys(byDay).sort().map(function (key) { return { date: key, amount: byDay[key] }; }),
    byMethod: Object.keys(methods).sort().map(function (key) { return { method: key, amount: methods[key] }; }),
    byRoom: Object.keys(byRoom).sort().map(function (key) { return { room: key, amount: byRoom[key] }; }),
    byRoomType: Object.keys(byRoomType).sort().map(function (key) { return { roomType: key, amount: byRoomType[key] }; })
  };
}
