# BÁO CÁO TỐI ƯU HIỆU SUẤT — HOTEL MANAGER PRO 3.1.1

## Nguyên tắc tương thích

Bản 3.1.1 không đổi 21 tên trang tính, không đổi thứ tự/tên cột, không đổi hàng tiêu đề 4 và hàng dữ liệu 5, không xóa hàm cũ, không đổi ID phần tử giao diện và không sửa định dạng giao diện. Toàn bộ dữ liệu bản 3.0.0/3.1.0 tiếp tục được đọc trực tiếp.

## Các điểm gây chậm đã xử lý

| Luồng | Trước tối ưu | Sau tối ưu |
| --- | --- | --- |
| Mở phần mềm tại Dashboard | Gọi khởi động, gọi phát sinh riêng và tự kiểm tra phòng trống | Một gói khởi động; phòng trống chỉ tải khi mở Đặt phòng |
| Lưu thông tin chung | 9 lượt gọi máy chủ, 18 lần ghi riêng cài đặt/nhật ký | 1 lượt gọi máy chủ, tối đa 3 lần ghi theo lô |
| Đọc lặp cùng một trang trong một nghiệp vụ | Mỗi hàm con có thể đọc lại toàn bộ trang | Mỗi trang đọc một lần trong lượt xử lý, tự hủy bản nhớ khi có ghi |
| Tra cứu mã | Lọc toàn bộ mảng ở mỗi lần tìm | Lập chỉ mục theo cột khóa và dùng lại trong lượt xử lý |
| Tìm phòng theo lịch | Mỗi phòng lại lọc toàn bộ đặt phòng và lưu trú | Gom lịch theo mã phòng một lần rồi đối chiếu từng phòng |
| Đặt nhiều phòng | Kiểm tra lịch, khách và trạng thái lặp lại cho từng phiếu | Kiểm tra trước một lần, dùng chung mã khách, cập nhật trạng thái theo lô |
| Tạo hóa đơn nhiều dịch vụ | Thêm từng dòng và sửa từng phát sinh | Thêm toàn bộ dòng hóa đơn và sửa toàn bộ phát sinh theo lô |
| Đồng bộ trạng thái toàn bộ phòng | Lặp đọc/ghi theo từng phòng | Tính trạng thái một lần và cập nhật theo lô |
| Mở Web App sau khi cập nhật mã | Tự chạy setup, định dạng và validation toàn bộ 21 trang | Chỉ kiểm tra tên trang; setup đầy đủ chỉ chạy khi thiếu trang |
| Dự án Web App không có bảng tính active | Có thể dừng vì không tìm được bảng tính | Dùng thuộc tính liên kết; nếu thiếu thì mở bảng tính mặc định đã bàn giao |
| Trả dữ liệu khởi động | Trả trực tiếp đối tượng tổng hợp | Chuẩn hóa JSON, loại `undefined` và số không hữu hạn trước khi trả |

Các số trên là số lượt gọi/ghi theo đường đi của mã, không phải cam kết thời gian mili-giây. Thời gian thực tế còn phụ thuộc số dòng, mạng, tài khoản Google và giới hạn Apps Script.

## Cơ chế an toàn dữ liệu

- `LockService` vẫn bao quanh toàn bộ nghiệp vụ ghi.
- Không dùng bộ nhớ đệm dài hạn cho đặt phòng, lưu trú, hóa đơn hoặc tồn kho.
- Sau mỗi lần ghi, dữ liệu và chỉ mục của trang liên quan được hủy ngay.
- Các cột ngoài phạm vi bản vá được đọc lại và ghi nguyên trạng khi cập nhật dòng.
- Hóa đơn đã khóa vẫn không được sửa trực tiếp.
- Kiểm tra trùng lịch vẫn chạy trước đặt phòng, nhận phòng, chuyển phòng và gia hạn.

## Khuyến nghị vận hành lâu dài

- Không tạo công thức kéo xuống hàng chục nghìn dòng trong các trang nhật ký.
- Hạn chế định dạng toàn cột hoặc chèn ảnh dung lượng lớn trực tiếp vào Sheet.
- Dùng giao diện phần mềm cho nghiệp vụ ghi để trạng thái và nhật ký đồng bộ.
- Sao lưu trước khi nâng cấp và kiểm tra một quy trình hoàn chỉnh trên bản sao.
- Khi dữ liệu nhiều năm tăng rất lớn, nên lưu trữ các giao dịch đã khóa theo năm; chỉ thực hiện sau khi có bản sao và quy trình đối soát.

## Kết quả kiểm tra tự động

- Cú pháp 11 tệp `.gs`: đạt.
- Cú pháp 3 tệp HTML/JavaScript: đạt.
- Lời gọi giao diện không thiếu hàm máy chủ: đạt.
- ID giao diện và hàm sự kiện không thiếu: đạt.
- 21/21 trang và toàn bộ cột so với 3.0.0: giống nhau.
- Không mất hàm máy chủ hoặc hàm giao diện cũ.
- Khóa PIN tài chính, số đêm, đặt nhiều phòng, phân bổ cọc, logo, buồng phòng và tìm phòng thông minh: đạt kiểm tra hồi quy tĩnh.

Vẫn cần chạy nghiệm thu thực tế trên một bản sao Google Sheet vì môi trường kiểm thử cục bộ không thể mô phỏng đầy đủ độ trễ, phân quyền và hạn mức của tài khoản Google.
