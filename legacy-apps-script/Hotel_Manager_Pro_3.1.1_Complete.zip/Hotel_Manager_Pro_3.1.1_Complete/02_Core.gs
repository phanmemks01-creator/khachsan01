/**
 * Bộ nhớ trong một lượt thực thi Apps Script.
 * Không lưu dữ liệu nghiệp vụ qua CacheService nên các thay đổi trực tiếp trên
 * Google Sheet luôn được nhìn thấy ở lượt gọi máy chủ kế tiếp.
 */
var HMS_RUNTIME_ = {
  spreadsheet: null,
  sheets: {},
  headers: {},
  objects: {},
  indexes: {}
};

function hmsSpreadsheet_() {
  if (HMS_RUNTIME_.spreadsheet) return HMS_RUNTIME_.spreadsheet;
  const props = PropertiesService.getScriptProperties();
  const id = props.getProperty('HMS3_SPREADSHEET_ID');
  if (id) {
    try {
      HMS_RUNTIME_.spreadsheet = SpreadsheetApp.openById(id);
      return HMS_RUNTIME_.spreadsheet;
    } catch (ignore) {
      props.deleteProperty('HMS3_SPREADSHEET_ID');
    }
  }
  const active = SpreadsheetApp.getActiveSpreadsheet();
  if (active) {
    props.setProperty('HMS3_SPREADSHEET_ID', active.getId());
    HMS_RUNTIME_.spreadsheet = active;
    return HMS_RUNTIME_.spreadsheet;
  }
  if (HMS.DEFAULT_SPREADSHEET_ID) {
    try {
      HMS_RUNTIME_.spreadsheet = SpreadsheetApp.openById(HMS.DEFAULT_SPREADSHEET_ID);
      props.setProperty('HMS3_SPREADSHEET_ID', HMS.DEFAULT_SPREADSHEET_ID);
      return HMS_RUNTIME_.spreadsheet;
    } catch (error) {
      throw new Error('Không mở được bảng tính mặc định ' + HMS.DEFAULT_SPREADSHEET_ID + '. Hãy cấp quyền rồi chạy repairHotelManagerConnection().');
    }
  }
  throw new Error('Chưa liên kết bảng tính. Hãy chạy repairHotelManagerConnection() một lần.');
}

/** Chuyển mọi dữ liệu trả về giao diện thành kiểu JSON thuần mà google.script.run hỗ trợ. */
function hmsJsonSafe_(value) {
  return JSON.parse(JSON.stringify(value, function (key, item) {
    if (typeof item === 'undefined') return '';
    if (typeof item === 'number' && !isFinite(item)) return 0;
    return item;
  }));
}

function hmsSheet_(sheetName) {
  if (HMS_RUNTIME_.sheets[sheetName]) return HMS_RUNTIME_.sheets[sheetName];
  const sheet = hmsSpreadsheet_().getSheetByName(sheetName);
  if (!sheet) throw new Error('Thiếu trang tính ' + sheetName + '.');
  HMS_RUNTIME_.sheets[sheetName] = sheet;
  return sheet;
}

function hmsHeaders_(sheet) {
  const sheetName = sheet.getName();
  if (HMS_RUNTIME_.headers[sheetName]) return HMS_RUNTIME_.headers[sheetName];
  const configured = HMS.HEADERS[sheetName] || [];
  const width = Math.max(1, sheet.getLastColumn(), configured.length);
  const headers = sheet.getRange(HMS.HEADER_ROW, 1, 1, width).getDisplayValues()[0].map(function (x) { return String(x || '').trim(); });
  HMS_RUNTIME_.headers[sheetName] = headers;
  return headers;
}

function hmsInvalidate_(sheetName, headersChanged) {
  delete HMS_RUNTIME_.objects[sheetName];
  Object.keys(HMS_RUNTIME_.indexes).forEach(function (key) {
    if (key.indexOf(sheetName + '::') === 0) delete HMS_RUNTIME_.indexes[key];
  });
  if (headersChanged) delete HMS_RUNTIME_.headers[sheetName];
}

function hmsObjects_(sheetName) {
  if (Object.prototype.hasOwnProperty.call(HMS_RUNTIME_.objects, sheetName)) return HMS_RUNTIME_.objects[sheetName];
  const sheet = hmsSheet_(sheetName);
  if (sheet.getLastRow() < HMS.DATA_ROW) {
    HMS_RUNTIME_.objects[sheetName] = [];
    return HMS_RUNTIME_.objects[sheetName];
  }
  const headers = hmsHeaders_(sheet);
  const values = sheet.getRange(HMS.DATA_ROW, 1, sheet.getLastRow() - HMS.DATA_ROW + 1, headers.length).getValues();
  HMS_RUNTIME_.objects[sheetName] = values.map(function (row, index) {
    const out = { _rowNumber: HMS.DATA_ROW + index };
    headers.forEach(function (h, col) { if (h) out[h] = row[col]; });
    return out;
  }).filter(function (row) { return headers.some(function (h) { return h && String(row[h] == null ? '' : row[h]).trim(); }); });
  return HMS_RUNTIME_.objects[sheetName];
}

function hmsAppend_(sheetName, object) {
  const sheet = hmsSheet_(sheetName);
  const headers = hmsHeaders_(sheet);
  const row = Math.max(HMS.DATA_ROW, sheet.getLastRow() + 1);
  const values = headers.map(function (header) {
    return header && Object.prototype.hasOwnProperty.call(object || {}, header) ? object[header] : '';
  });
  sheet.getRange(row, 1, 1, headers.length).setValues([values]);
  hmsInvalidate_(sheetName, false);
  return row;
}

function hmsAppendMany_(sheetName, objects) {
  objects = Array.isArray(objects) ? objects.filter(function (x) { return x && typeof x === 'object'; }) : [];
  if (!objects.length) return [];
  const sheet = hmsSheet_(sheetName);
  const headers = hmsHeaders_(sheet);
  const startRow = Math.max(HMS.DATA_ROW, sheet.getLastRow() + 1);
  const values = objects.map(function (object) {
    return headers.map(function (header) {
      return header && Object.prototype.hasOwnProperty.call(object, header) ? object[header] : '';
    });
  });
  sheet.getRange(startRow, 1, values.length, headers.length).setValues(values);
  hmsInvalidate_(sheetName, false);
  return values.map(function (_, index) { return startRow + index; });
}

function hmsUpdate_(sheetName, rowNumber, patch) {
  const sheet = hmsSheet_(sheetName);
  const headers = hmsHeaders_(sheet);
  const current = sheet.getRange(rowNumber, 1, 1, headers.length).getValues()[0];
  Object.keys(patch || {}).forEach(function (key) {
    const col = headers.indexOf(key);
    if (col >= 0) current[col] = patch[key];
  });
  sheet.getRange(rowNumber, 1, 1, headers.length).setValues([current]);
  hmsInvalidate_(sheetName, false);
  return rowNumber;
}

function hmsUpdateMany_(sheetName, updates) {
  updates = Array.isArray(updates) ? updates.filter(function (x) { return x && x.rowNumber >= HMS.DATA_ROW; }) : [];
  if (!updates.length) return 0;
  const sheet = hmsSheet_(sheetName);
  const headers = hmsHeaders_(sheet);
  const rows = updates.map(function (x) { return Number(x.rowNumber); });
  const firstRow = Math.min.apply(null, rows), lastRow = Math.max.apply(null, rows);
  const values = sheet.getRange(firstRow, 1, lastRow - firstRow + 1, headers.length).getValues();
  updates.forEach(function (update) {
    const target = values[Number(update.rowNumber) - firstRow];
    Object.keys(update.patch || {}).forEach(function (key) {
      const col = headers.indexOf(key);
      if (col >= 0) target[col] = update.patch[key];
    });
  });
  sheet.getRange(firstRow, 1, values.length, headers.length).setValues(values);
  hmsInvalidate_(sheetName, false);
  return updates.length;
}

function hmsUpsert_(sheetName, key, value, object) {
  const found = hmsFind_(sheetName, key, value);
  return found ? hmsUpdate_(sheetName, found._rowNumber, object) : hmsAppend_(sheetName, object);
}

function hmsDeleteRowsByKey_(sheetName, key, value) {
  const sheet = hmsSheet_(sheetName);
  const headers = hmsHeaders_(sheet);
  const first = headers[0];
  const updates = hmsObjects_(sheetName).filter(function (row) { return String(row[key] || '') === String(value); }).map(function (row) {
    const blank = {};
    headers.forEach(function (h) { if (h) blank[h] = ''; });
    blank[first] = '';
    return { rowNumber: row._rowNumber, patch: blank };
  });
  hmsUpdateMany_(sheetName, updates);
}

function hmsWithLock_(callback) {
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try { return callback(); } finally { lock.releaseLock(); }
}

function hmsId_(prefix) {
  const clean = String(prefix || 'ID').toUpperCase().replace(/[^A-Z0-9]/g, '');
  return clean + '-' + Utilities.formatDate(new Date(), HMS.TZ, 'yyyyMMdd-HHmmss') + '-' + Math.floor(100000 + Math.random() * 900000);
}

function hmsSafe_(value) {
  return String(value == null ? '' : value).trim().replace(/[<>]/g, '');
}

function hmsMoney_(value) {
  const n = Number(value || 0);
  return isFinite(n) ? Math.max(0, Math.round(n)) : 0;
}

function hmsNumber_(value, fallback) {
  const n = Number(value);
  return isFinite(n) ? n : Number(fallback || 0);
}

function hmsBool_(value) {
  const text = String(value == null ? '' : value).trim().toLowerCase();
  return value === true || value === 1 || text === 'true' || text === 'có' || text === '1' || text === 'yes';
}

function hmsActive_(value) {
  return String(value == null ? '' : value).trim() === '' ? true : hmsBool_(value);
}

function hmsNormalize_(value) {
  return String(value || '').trim().toUpperCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/Đ/g, 'D');
}

function hmsDate_(value) {
  if (!value) return null;
  if (Object.prototype.toString.call(value) === '[object Date]' && !isNaN(value)) return value;
  const date = new Date(value);
  return isNaN(date) ? null : date;
}

function hmsDateKey_(value) {
  const date = hmsDate_(value);
  return date ? Utilities.formatDate(date, HMS.TZ, 'yyyy-MM-dd') : '';
}

function hmsDateTimeInput_(value) {
  const date = hmsDate_(value);
  return date ? Utilities.formatDate(date, HMS.TZ, "yyyy-MM-dd'T'HH:mm") : '';
}

function hmsDateTimeText_(value) {
  const date = hmsDate_(value);
  return date ? Utilities.formatDate(date, HMS.TZ, 'dd/MM/yyyy HH:mm') : '';
}

function hmsStartDay_(value) {
  const date = hmsDate_(value) || new Date();
  return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0, 0);
}

function hmsEndDay_(value) {
  const date = hmsDate_(value) || new Date();
  return new Date(date.getFullYear(), date.getMonth(), date.getDate(), 23, 59, 59, 999);
}

function hmsNights_(start, end) {
  const a = hmsDate_(start), b = hmsDate_(end);
  if (!a || !b) return 1;
  const x = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
  const y = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());
  return Math.max(1, Math.round((y - x) / 86400000));
}

function hmsIntervalsOverlap_(aStart, aEnd, bStart, bEnd) {
  return Number(aStart) < Number(bEnd) && Number(aEnd) > Number(bStart);
}

function hmsUser_() {
  return Session.getActiveUser().getEmail() || 'Người dùng';
}

function hmsLog_(action, objectType, objectId, content) {
  hmsAppend_(HMS.SHEETS.AUDIT, {
    THOI_GIAN: new Date(), NGUOI_DUNG: hmsUser_(), HANH_DONG: action,
    DOI_TUONG: objectType, MA_DOI_TUONG: objectId, NOI_DUNG: hmsSafe_(content)
  });
}

function hmsSettings_() {
  const out = {};
  hmsObjects_(HMS.SHEETS.SETTINGS).forEach(function (row) { if (row.KHOA) out[String(row.KHOA)] = row.GIA_TRI; });
  return out;
}

function hmsSaveSetting(data) {
  data = data || {};
  const key = hmsSafe_(data.key).toUpperCase();
  if (!key) throw new Error('Thiếu khóa cài đặt.');
  return hmsWithLock_(function () {
    hmsUpsert_(HMS.SHEETS.SETTINGS, 'KHOA', key, {
      KHOA: key, GIA_TRI: data.value == null ? '' : data.value,
      NHOM: hmsSafe_(data.group) || 'Tùy chỉnh', MO_TA: hmsSafe_(data.description)
    });
    hmsLog_('Cập nhật cài đặt', 'Cài đặt', key, String(data.value == null ? '' : data.value));
    return 'Đã lưu cài đặt ' + key + '.';
  });
}

/** Lưu nhiều cài đặt trong một lần gọi giao diện và tối đa hai lần ghi Sheet. */
function saveHmsSettingsBatch(items) {
  items = Array.isArray(items) ? items : [];
  if (!items.length) throw new Error('Không có cài đặt cần lưu.');
  if (items.length > 50) throw new Error('Mỗi lần chỉ được lưu tối đa 50 cài đặt.');
  return hmsWithLock_(function () {
    const normalized = items.map(function (data) {
      data = data || {};
      const key = hmsSafe_(data.key).toUpperCase();
      if (!key) throw new Error('Có cài đặt chưa có khóa.');
      return {
        key: key,
        object: {
          KHOA: key, GIA_TRI: data.value == null ? '' : data.value,
          NHOM: hmsSafe_(data.group) || 'Tùy chỉnh', MO_TA: hmsSafe_(data.description)
        }
      };
    });
    const duplicateKeys = hmsDuplicates_(normalized.map(function (x) { return x.key; }));
    if (duplicateKeys.length) throw new Error('Khóa cài đặt bị trùng: ' + duplicateKeys.join(', ') + '.');
    const updates = [], appends = [], logs = [], user = hmsUser_(), now = new Date();
    normalized.forEach(function (item) {
      const found = hmsFind_(HMS.SHEETS.SETTINGS, 'KHOA', item.key);
      if (found) updates.push({ rowNumber: found._rowNumber, patch: item.object });
      else appends.push(item.object);
      logs.push({
        THOI_GIAN: now, NGUOI_DUNG: user, HANH_DONG: 'Cập nhật cài đặt',
        DOI_TUONG: 'Cài đặt', MA_DOI_TUONG: item.key, NOI_DUNG: String(item.object.GIA_TRI)
      });
    });
    hmsUpdateMany_(HMS.SHEETS.SETTINGS, updates);
    hmsAppendMany_(HMS.SHEETS.SETTINGS, appends);
    hmsAppendMany_(HMS.SHEETS.AUDIT, logs);
    return { ok: true, count: normalized.length, message: 'Đã lưu ' + normalized.length + ' cài đặt.' };
  });
}

function hmsDuplicates_(values) {
  const counts = {};
  values.forEach(function (value) { counts[value] = (counts[value] || 0) + 1; });
  return Object.keys(counts).filter(function (key) { return counts[key] > 1; });
}

function hmsFind_(sheetName, key, value) {
  const indexKey = sheetName + '::' + key;
  if (!HMS_RUNTIME_.indexes[indexKey]) {
    const index = {};
    hmsObjects_(sheetName).forEach(function (row) {
      const rowKey = String(row[key] == null ? '' : row[key]);
      if (!Object.prototype.hasOwnProperty.call(index, rowKey)) index[rowKey] = row;
    });
    HMS_RUNTIME_.indexes[indexKey] = index;
  }
  return HMS_RUNTIME_.indexes[indexKey][String(value)] || null;
}

function hmsRequire_(sheetName, key, value, label) {
  const row = hmsFind_(sheetName, key, value);
  if (!row) throw new Error('Không tìm thấy ' + (label || value) + '.');
  return row;
}

function hmsPercentSetting_(key) {
  const raw = hmsNumber_(hmsSettings_()[key], 0);
  return Math.max(0, Math.min(1, raw));
}

function hmsAssertRoomAvailable_(roomCode, start, end, excludeBookingId, excludeStayId) {
  const startMs = hmsDate_(start).getTime(), endMs = hmsDate_(end).getTime();
  if (endMs <= startMs) throw new Error('Thời gian trả phòng phải sau thời gian nhận phòng.');
  const conflictBooking = hmsObjects_(HMS.SHEETS.BOOKINGS).filter(function (b) {
    if (String(b.MA_DAT_PHONG || '') === String(excludeBookingId || '')) return false;
    if (String(b.MA_PHONG || '') !== String(roomCode)) return false;
    if (HMS.BOOKING_CLOSED.indexOf(String(b.TRANG_THAI || '')) >= 0 || String(b.TRANG_THAI || '') === 'Đã nhận phòng') return false;
    const a = hmsDate_(b.NHAN_DU_KIEN), z = hmsDate_(b.TRA_DU_KIEN);
    return a && z && hmsIntervalsOverlap_(a.getTime(), z.getTime(), startMs, endMs);
  })[0];
  if (conflictBooking) throw new Error('Phòng ' + roomCode + ' đã có phiếu ' + conflictBooking.MA_DAT_PHONG + ' trùng thời gian.');
  const conflictStay = hmsObjects_(HMS.SHEETS.STAYS).filter(function (s) {
    if (String(s.MA_LUU_TRU || '') === String(excludeStayId || '')) return false;
    if (String(s.MA_PHONG || '') !== String(roomCode) || String(s.TRANG_THAI || '') !== 'Đang ở') return false;
    const a = hmsDate_(s.NHAN_PHONG), z = hmsDate_(s.TRA_DU_KIEN) || new Date(8640000000000000);
    return a && hmsIntervalsOverlap_(a.getTime(), z.getTime(), startMs, endMs);
  })[0];
  if (conflictStay) throw new Error('Phòng ' + roomCode + ' đang có khách ' + conflictStay.TEN_KHACH + '.');
}

function hmsRefreshRoomStatus_(roomCode) {
  const statuses = hmsRefreshRoomStatuses_([roomCode]);
  if (!Object.prototype.hasOwnProperty.call(statuses, String(roomCode))) throw new Error('Không tìm thấy phòng ' + roomCode + '.');
  return statuses[String(roomCode)];
}

function hmsRefreshAllRoomStatuses_() {
  const codes = hmsObjects_(HMS.SHEETS.ROOMS).filter(function (r) { return hmsActive_(r.HOAT_DONG); }).map(function (r) { return String(r.MA_PHONG || ''); });
  return hmsRefreshRoomStatuses_(codes);
}

function hmsRefreshRoomStatuses_(roomCodes) {
  const wanted = {};
  (Array.isArray(roomCodes) ? roomCodes : [roomCodes]).forEach(function (code) {
    code = String(code || '');
    if (code) wanted[code] = true;
  });
  const rooms = hmsObjects_(HMS.SHEETS.ROOMS).filter(function (room) { return wanted[String(room.MA_PHONG || '')]; });
  const occupied = {}, booked = {};
  hmsObjects_(HMS.SHEETS.STAYS).forEach(function (stay) {
    if (String(stay.TRANG_THAI || '') === 'Đang ở') occupied[String(stay.MA_PHONG || '')] = true;
  });
  hmsObjects_(HMS.SHEETS.BOOKINGS).forEach(function (booking) {
    const status = String(booking.TRANG_THAI || '');
    if (HMS.BOOKING_CLOSED.indexOf(status) < 0 && status !== 'Đã nhận phòng') booked[String(booking.MA_PHONG || '')] = true;
  });
  const statuses = {}, updates = [];
  rooms.forEach(function (room) {
    const code = String(room.MA_PHONG || ''), current = String(room.TRANG_THAI || '');
    if (['Chờ vệ sinh', 'Bảo trì', 'Tạm khóa'].indexOf(current) >= 0) {
      statuses[code] = current;
      return;
    }
    const next = occupied[code] ? 'Đang ở' : (booked[code] ? 'Đã đặt' : 'Phòng trống');
    statuses[code] = next;
    if (current !== next) updates.push({ rowNumber: room._rowNumber, patch: { TRANG_THAI: next } });
  });
  hmsUpdateMany_(HMS.SHEETS.ROOMS, updates);
  return statuses;
}
