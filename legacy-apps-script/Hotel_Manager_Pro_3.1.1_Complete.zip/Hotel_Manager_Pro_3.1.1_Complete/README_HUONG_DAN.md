# HOTEL MANAGER PRO 3.1.1 — BỘ ĐẦY ĐỦ, TỰ SỬA KẾT NỐI MÁY CHỦ

## 1. Mục đích

Đây là bộ phần mềm quản lý khách sạn mới chạy trên Google Sheets và Google Apps Script. Bộ mã sử dụng khóa liên kết riêng `HMS3_SPREADSHEET_ID`, không phụ thuộc dữ liệu hoặc thuộc tính của các phiên bản trước.

Phiên bản 3.1.1 giữ nguyên 21 trang tính, toàn bộ tên cột, hàng tiêu đề dòng 4, dữ liệu từ dòng 5, các ID giao diện và mọi hàm công khai của bản 3.0.0/3.1.0. Bản này bổ sung liên kết bảng tính dự phòng, phản hồi JSON an toàn và bộ chẩn đoán để xử lý lỗi “Máy chủ không trả dữ liệu”.

Các tối ưu chính:

- mỗi trang tính chỉ đọc một lần trong cùng một lượt xử lý máy chủ;
- dùng chỉ mục trong bộ nhớ cho tra cứu mã phòng, mã khách, phiếu đặt và hóa đơn;
- ghi nhiều dòng hóa đơn, cập nhật nhiều phát sinh và trạng thái phòng theo lô;
- lưu chín cài đặt chung bằng một lần gọi máy chủ thay vì chín lần;
- dữ liệu phát sinh được đưa vào gói khởi động để giao diện không gọi máy chủ lần thứ hai;
- chỉ tải bảng phòng trống khi người dùng mở mục Đặt phòng;
- tìm phòng theo lịch được lập chỉ mục theo từng phòng, không quét lại toàn bộ lịch cho từng thẻ phòng;
- không lưu dữ liệu nghiệp vụ lâu dài trong bộ nhớ đệm, vì vậy sửa trực tiếp trên Sheet sẽ xuất hiện ở lần gọi máy chủ kế tiếp.
- Web App tự mở đúng bảng tính bàn giao khi thuộc tính liên kết chưa được tạo;
- lần mở giao diện chỉ kiểm tra nhanh 21 tên trang, không tự định dạng lại toàn bộ bảng tính;
- mọi gói dữ liệu khởi động được chuyển thành JSON thuần trước khi trả về giao diện.

Quy trình nghiệp vụ:

**Đặt phòng → Nhận phòng → Lưu trú → Phát sinh đồ giải khát/dịch vụ → Trả phòng → Lập hóa đơn → Thanh toán → In hóa đơn → Vệ sinh phòng → Mở lại phòng → Thống kê doanh thu.**

Mỗi phòng được kinh doanh nguyên phòng. Hệ thống không có giường ghép.

## 2. Các phân hệ

- Dashboard tình trạng và hiệu suất phòng.
- Sơ đồ phòng theo tầng, loại phòng và trạng thái.
- Đặt một hoặc nhiều phòng cho cùng một người đặt.
- Tìm phòng trống thông minh bằng gõ tên, lọc loại phòng hoặc chọn trực tiếp.
- Hiển thị tổng số và số phòng trống theo từng loại phòng.
- Nhận phòng từ phiếu đặt hoặc mở phòng cho khách vãng lai.
- Quản lý khách đang lưu trú, gia hạn và chuyển phòng.
- Ghi nhận đồ giải khát, dịch vụ và phụ thu.
- Quản lý tồn kho minibar, nhập kho và tự trừ kho khi phát sinh.
- Trả phòng, tính số đêm và tiền phòng theo giá ngày thường/cuối tuần.
- Lập hóa đơn, giảm tiền có lý do, nhận cọc và thu tiền nhiều lần.
- In hóa đơn theo mẫu có logo, thông tin khách sạn và lời cảm ơn.
- Quản lý vệ sinh buồng phòng, bảo trì và mở lại phòng.
- Báo cáo tài chính từ ngày đến ngày, có PIN bảo vệ.
- Cài đặt tên khách sạn, logo, giá phòng, danh mục phòng và dịch vụ.
- Nhật ký thao tác.

## 3. Danh sách tệp cần tạo trong Apps Script

### Tệp Script `.gs`

1. `00_Config.gs`
2. `01_Setup.gs`
3. `02_Core.gs`
4. `03_Server_Diagnostics.gs`
5. `20_Catalogs.gs`
6. `30_Bookings.gs`
7. `40_Stays_Charges.gs`
8. `50_Billing.gs`
9. `60_Housekeeping.gs`
10. `70_Dashboard_Finance.gs`
11. `75_Finance_Security.gs`

### Tệp HTML

1. `Index.html`
2. `90_Client.html`
3. `90_Styles.html`

Thêm nội dung trong `appsscript.json` vào tệp manifest của dự án.

## 4. Cài đặt vào Google Sheet hoàn toàn mới

1. Tạo một Google Sheet trống.
2. Chọn **Tiện ích mở rộng → Apps Script**.
3. Xóa mã mẫu trong dự án.
4. Tạo đủ các tệp ở mục 3 và dán đúng nội dung tương ứng.
5. Trong **Project Settings**, bật hiển thị `appsscript.json` rồi thay nội dung bằng manifest trong bộ mã.
6. Lưu toàn bộ dự án.
7. Chọn hàm `setupHotelManager` và nhấn **Run**.
8. Cấp quyền truy cập Google Sheets khi Google yêu cầu.
9. Chờ hoàn tất rồi tải lại bảng tính.
10. Chọn **🏨 HOTEL MANAGER PRO 3.1.1 → Mở phần mềm**.

Không dán bộ mã v3 chung với tệp của phiên bản cũ. Bộ mới phải nằm trong một dự án Apps Script riêng hoặc thay toàn bộ nội dung dự án.

## 4A. Nâng cấp từ Hotel Manager Pro 3.0.0

1. Tạo một bản sao Google Sheet hiện tại để dự phòng.
2. Mở **Tiện ích mở rộng → Apps Script**.
3. Thay đồng bộ toàn bộ 11 tệp `.gs`, 3 tệp HTML và `appsscript.json` bằng bộ 3.1.1.
4. Không xóa hoặc đổi tên bất kỳ trang tính nào.
5. Chạy `repairHotelManagerConnection()` một lần. Hàm liên kết bảng tính, kiểm tra và bổ sung cấu trúc còn thiếu, không xóa dữ liệu cũ.
6. Chạy `runHotelHealthCheck()` và xác nhận `ok: true`.
7. Tải lại Google Sheet.
8. Nếu đang dùng Web App, chọn **Deploy → Manage deployments → Edit → New version → Deploy**.

Không cần nhập lại danh mục phòng, bảng giá, đặt phòng, lưu trú, hóa đơn, phiếu thu, tồn kho hoặc cài đặt.

## 5. Tạo tự động bảng tính khách sạn mới

Sau khi thêm bộ mã vào Apps Script, chạy:

```javascript
createNewHotelManagerSpreadsheet()
```

Hàm sẽ tạo Google Sheet mới, 21 trang dữ liệu, 20 phòng mẫu, ba bảng giá và danh mục đồ giải khát/dịch vụ.

## 6. Triển khai Web App

1. Chọn **Deploy → New deployment**.
2. Chọn loại **Web app**.
3. Execute as: **User deploying the web app**.
4. Chọn phạm vi người dùng phù hợp.
5. Nhấn **Deploy** và mở đường dẫn được cấp.

Khi cập nhật mã, phải vào **Deploy → Manage deployments → Edit → New version → Deploy**. Nếu chỉ lưu mã, Web App có thể vẫn chạy phiên bản cũ.

## 7. Cấu hình ban đầu

Vào **Cài đặt** để thay đổi:

- tên, địa chỉ, điện thoại, email và mã số thuế;
- logo bằng nút chọn tệp;
- giờ nhận phòng và trả phòng;
- tiêu đề và lời cảm ơn trên hóa đơn;
- giá phòng ngày thường và cuối tuần;
- tên phòng, tầng, loại phòng, sức chứa và trạng thái;
- danh mục đồ giải khát/dịch vụ, giá bán và giá nhập;
- thuế GTGT, phí dịch vụ;
- khóa tài chính và thời gian duy trì phiên.

PIN tài chính mặc định: `2468`. Cần đổi ngay sau khi cài đặt.

## 8. Quy tắc tính tiền

- Số đêm tối thiểu là 1.
- Tiền phòng lấy theo loại phòng, bảng giá có hiệu lực và ngày thường/cuối tuần.
- Đơn giá được lưu tại thời điểm nhận phòng để bảo đảm lịch sử.
- Đồ giải khát/dịch vụ = số lượng × đơn giá tại thời điểm phát sinh.
- Tổng thanh toán = tiền phòng + dịch vụ + phụ thu + phí dịch vụ + thuế − giảm tiền.
- Tiền cọc và các lần thu được đối trừ vào số còn phải thu.
- Chỉ hóa đơn đủ tiền mới chuyển sang `Đã thanh toán` và được tính vào doanh thu.

## 9. Một người đặt nhiều phòng

- Chọn nhiều phòng trong vùng tìm phòng trống.
- Mỗi phòng tạo một phiếu đặt riêng để theo dõi độc lập.
- Các phiếu dùng chung `MA_NHOM_DAT`.
- Danh sách đặt phòng hiển thị đúng số dòng bằng số phòng đã đặt.
- Tiền cọc nhóm được phân bổ cho từng phòng, không nhân đôi.

## 10. Khắc phục lỗi thường gặp

### `Cannot read properties of null (reading 'version')`

- Kiểm tra đã cài đủ `03_Server_Diagnostics.gs`, `70_Dashboard_Finance.gs` và `90_Client.html`.
- Chạy `repairHotelManagerConnection()` một lần.
- Nếu dùng Web App, tạo phiên bản triển khai mới.
- Không trộn tệp HTML của v3 với tệp `.gs` của bản cũ.

### `Máy chủ không trả dữ liệu`

1. Chạy `getHmsServerStatus()` trong Apps Script. Kết quả phải có `ok: true`, đúng `spreadsheetId` và `missingSheets: []`.
2. Nếu chưa đúng, chạy `repairHotelManagerConnection()`; nếu muốn buộc về bảng tính bàn giao, chạy `linkHotelManagerToDefaultSpreadsheet()`.
3. Chọn **Deploy → Manage deployments → Edit → New version → Deploy**. Chỉ bấm Save không cập nhật mã của Web App đang mở.
4. Mở URL triển khai mới và tải lại trang.

### Không hiện danh sách phòng hoặc giá phòng

- Chạy `setupHotelManager()`.
- Kiểm tra `DM_PHONG` có tiêu đề tại dòng 4 và dữ liệu từ dòng 5.
- Kiểm tra `BANG_GIA_PHONG` có bảng giá đang hoạt động.
- Vào **Cài đặt → Danh sách tên phòng và giá hiện hành**.

## 11. Kiểm tra hệ thống

Chạy:

```javascript
runHotelHealthCheck()
```

Kết quả hợp lệ phải có `ok: true`, `version: 3.1.1`, không thiếu trang và không trùng mã phòng/đặt phòng.

## 12. Lưu ý vận hành

- Không đổi tên các trang dữ liệu.
- Không sửa hàng tiêu đề dòng 4.
- Nên bảo vệ `HOA_DON`, `PHIEU_THU`, `NHAT_KY` khỏi sửa thủ công.
- Sao lưu bảng tính định kỳ.
- Thực hiện nghiệp vụ từ giao diện để trạng thái phòng, tồn kho và doanh thu luôn đồng bộ.
