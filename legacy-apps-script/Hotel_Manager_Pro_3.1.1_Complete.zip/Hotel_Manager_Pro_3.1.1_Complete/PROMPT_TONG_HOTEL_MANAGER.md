# PROMPT TỔNG – HOTEL MANAGER PRO 3.1.1, TỐI ƯU VÀ TỰ SỬA KẾT NỐI

Bạn là kiến trúc sư phần mềm và chuyên gia quản lý vận hành khách sạn có 20 năm kinh nghiệm. Hãy xây dựng một bộ phần mềm quản lý khách sạn mới, độc lập hoàn toàn bằng Google Apps Script và Google Sheets, giao diện tiếng Việt, chạy trong menu Google Sheets và có thể triển khai thành Web App.

## Mục tiêu bắt buộc

Tạo hệ thống có luồng xuyên suốt:

`Phòng trống → Đặt phòng → Nhận phòng → Lưu trú → Phát sinh đồ giải khát/dịch vụ → Gia hạn hoặc chuyển phòng → Trả phòng → Hóa đơn → Thu tiền → In hóa đơn → Vệ sinh → Mở bán lại → Thống kê doanh thu`.

Mỗi phòng được kinh doanh nguyên phòng. Không xây dựng mô hình bán chỗ hoặc dùng chung phòng. Hệ thống phải hiển thị rõ số phòng, tên khách, ngày giờ nhận–trả, số đêm, đơn giá, tiền phòng, tiền dịch vụ, phụ thu, giảm tiền, tiền cọc, phí dịch vụ, thuế, đã thu và số còn phải thu.

## Chức năng nghiệp vụ

1. **Dashboard**
   - Tổng phòng, trống, đã đặt, đang ở, chờ vệ sinh, bảo trì.
   - Công suất phòng, khách đến/trả hôm nay.
   - Hóa đơn chờ, công nợ, doanh thu tháng.
   - Cảnh báo buồng phòng, bảo trì và tồn minibar.

2. **Phòng và bảng giá**
   - Phòng đơn, phòng đôi, phòng gia đình; tầng, sức chứa, trạng thái và hoạt động.
   - Bảng giá là mục riêng trên menu và chỉnh được trong Cài đặt.
   - Giá ngày thường/cuối tuần, ngày hiệu lực, ưu tiên và trạng thái hoạt động.
   - Khi tạo hóa đơn phải chụp giá để hóa đơn cũ không đổi theo giá mới.

3. **Đặt phòng**
   - Tìm phòng trống theo khoảng ngày giờ.
   - Một khách/đoàn được chọn nhiều phòng trong một lần; gõ ngay trong ô `Phòng còn trống` theo mã/tên/tầng/loại phòng rồi chọn liên tiếp, hoặc lọc theo tầng, loại phòng, sức chứa, trạng thái rồi nhấn nhiều thẻ phòng.
   - Ô gõ–chọn phải tìm được cả tiếng Việt có dấu và không dấu; không cho lưu nếu chưa chọn ít nhất một phòng cụ thể; phòng đã chọn không xuất hiện lại trong gợi ý.
   - Mỗi phòng tạo một phiếu/dòng độc lập để nhận, trả, hủy và lập hóa đơn riêng; các phiếu cùng khách dùng chung `MA_NHOM_DAT` và danh sách phải hiện đúng bao nhiêu phòng là bấy nhiêu dòng.
   - Cho phép nhập số khách riêng từng phòng; chặn vượt sức chứa. Khi có nhiều loại phòng, tự áp dụng bảng giá đúng cho từng phòng.
   - Tiền cọc nhập theo tổng nhóm và phân bổ theo giá dự kiến sao cho tổng cọc từng phòng đúng tuyệt đối bằng số đã thu, không bị nhân đôi.
   - Loại phòng trong bộ lọc phải lấy động từ danh mục phòng, không viết cố định trong HTML.
   - Hiển thị số phòng còn trống/tổng số theo từng loại phòng và cho phép nhấn vào chỉ số để lọc nhanh.
   - Hiển thị bảng phòng trực quan gồm phòng trống, đang có khách, đã đặt, chờ vệ sinh, bảo trì và lý do chưa thể chọn.
   - Danh sách phiếu có tìm nhanh, lọc từ ngày đến ngày và trạng thái; dữ liệu cũ trong bảng đặt phòng vẫn phải hiển thị.
   - Chặn trùng lịch theo quy tắc khoảng thời gian giao nhau.
   - Tên khách, điện thoại, giấy tờ, số người, kênh đặt, tiền cọc và ghi chú.
   - Có khách đặt trước và khách vãng lai; nút mở/nhận phòng ngay.
   - Hủy, không đến và hoàn tiền cọc phải có dấu vết.

4. **Lưu trú**
   - Số đêm tối thiểu bằng 1; tính theo ngày nhận và ngày trả thực tế.
   - Cho phép gia hạn nhưng phải kiểm tra phiếu đặt tiếp theo.
   - Cho phép chuyển phòng; lưu phòng cũ, phòng mới, thời gian, giá và phụ thu.
   - Phòng cũ chuyển chờ vệ sinh; phòng mới chuyển đang ở.

5. **Đồ giải khát, dịch vụ và minibar**
   - Giữ nguyên cấu trúc cũ; bổ sung danh mục đồ giải khát.
   - Danh mục, loại, đơn vị, giá nhập, giá bán, hoạt động và thứ tự.
   - Ghi phát sinh theo mã lưu trú; hiển thị lại trong danh mục tính tiền.
   - Có tồn đầu, nhập, xuất, tồn hiện tại, tồn tối thiểu và cảnh báo sắp hết.
   - Mặt hàng theo dõi tồn tự trừ khi ghi phát sinh và hoàn lại khi hủy hợp lệ.

6. **Trả phòng, hóa đơn và thanh toán**
   - Trả phòng chuyển trực tiếp sang bảng thanh toán.
   - Công thức: tiền phòng + dịch vụ + phụ thu − giảm tiền + phí dịch vụ + thuế − tiền cọc − các lần đã thu.
   - Giảm tiền bắt buộc có lý do và không vượt giá trị trước giảm.
   - Hỗ trợ nhiều phiếu thu: tiền mặt, chuyển khoản, thẻ; thu một phần hoặc đủ.
   - Chỉ khóa hóa đơn khi số còn phải thu bằng 0.
   - Không hủy hóa đơn đã có phiếu thu nếu chưa xử lý hoàn tiền.
   - Mẫu in hóa đơn chỉnh được: logo, tên khách sạn, địa chỉ, điện thoại, mã số thuế, tiêu đề, lời cảm ơn.
   - Logo cho phép chọn tệp PNG/JPG/WebP, xem trước, xóa, tự thu nhỏ/nén trước khi lưu; vẫn hỗ trợ liên kết ảnh trực tiếp công khai.

7. **Buồng phòng và bảo trì**
   - Tự tạo việc vệ sinh khi trả/chuyển phòng.
   - Trạng thái chờ, đang làm, hoàn thành; người nhận và thời gian.
   - Bảo trì có sự cố, mức độ, người xử lý và kết quả.
   - Không mở bán phòng khi còn việc vệ sinh hoặc bảo trì chưa hoàn thành.

8. **Tài chính và báo cáo**
   - Khóa bằng PIN phía máy chủ; PIN lưu dưới dạng băm, không lưu văn bản rõ trong Sheet.
   - Sau số lần nhập sai quy định phải tạm khóa; phiên mở khóa có thời hạn và có thể khóa lại thủ công.
   - Doanh thu từ ngày đến ngày, chỉ gồm hóa đơn đã thanh toán theo ngày thanh toán.
   - Thực thu theo phiếu thu/hoàn tiền trong kỳ.
   - Tiền phòng, đồ giải khát, dịch vụ, phụ thu, giảm, phí dịch vụ, thuế và công nợ.
   - Chi tiết theo hóa đơn, ngày, phòng, loại phòng, khách và phương thức thanh toán.

9. **Nhật ký và an toàn dữ liệu**
   - Ghi thời gian, người dùng, hành động, đối tượng, mã và nội dung.
   - Dùng `LockService` cho mọi thao tác ghi quan trọng.
   - Mọi hàm khởi tạo phải idempotent: chạy lại không xóa hoặc nhân đôi dữ liệu.
   - Không xóa giao dịch tài chính; dùng trạng thái hủy.
   - Kiểm tra dữ liệu đầu vào, mã định danh, sức chứa, số tiền, ngày giờ và trạng thái chuyển tiếp.

## Yêu cầu kiến trúc mã

- Chia mã thành các tệp nhỏ theo mô-đun: cấu hình, setup, core, danh mục, đặt phòng, lưu trú, dịch vụ, hóa đơn, buồng phòng, tài chính, giao diện.
- Không khai báo trùng hàm hoặc biến toàn cục.
- Tên hàm giao tiếp HTML–server phải thống nhất tuyệt đối.
- Dùng một hàm `include()` để ghép HTML/CSS/JavaScript.
- Hạn chế gọi `getRange().setValue()` lặp nhiều lần; ưu tiên ghi theo hàng hoặc khối.
- Trong cùng một lượt gọi máy chủ, mỗi trang chỉ được đọc một lần và phải hủy dữ liệu nhớ của trang ngay sau khi ghi.
- Tra cứu nhiều lần theo mã phải dùng chỉ mục trong bộ nhớ của lượt xử lý, không lọc lại toàn bộ mảng.
- Gom cài đặt, chi tiết hóa đơn, cập nhật phát sinh và trạng thái phòng thành các lệnh ghi theo lô.
- Màn hình đầu chỉ tải dữ liệu cần thiết; danh sách phòng theo lịch chỉ gọi khi người dùng mở Đặt phòng hoặc thay đổi ngày.
- Không dùng bộ nhớ đệm dài hạn cho đặt phòng, lưu trú, hóa đơn hoặc tồn kho nếu không có cơ chế phiên bản và hủy bộ nhớ chính xác.
- Không dùng công thức toàn cột gây chậm; giới hạn vùng dữ liệu.
- Mọi ngày giờ dùng múi giờ `Asia/Ho_Chi_Minh`.
- Có hàm kiểm tra hệ thống và hướng dẫn cài đặt.

## Cấu trúc Sheet tối thiểu

`HUONG_DAN`, `CAI_DAT`, `BANG_GIA_PHONG`, `DM_PHONG`, `DM_DICH_VU`, `DM_KHACH_HANG`, `DAT_PHONG`, `LUU_TRU`, `CHUYEN_PHONG`, `PHAT_SINH`, `HOA_DON`, `CT_HOA_DON`, `PHIEU_THU`, `BUONG_PHONG`, `BAO_TRI`, `KHO_MINIBAR`, `NHAP_KHO`, `XUAT_KHO`, `NHAT_KY`, `DOANH_THU`, `DASHBOARD`.

## Tiêu chuẩn giao diện

- Responsive cho máy tính và điện thoại.
- Menu trái rõ ràng; bảng có cuộn; trạng thái bằng badge màu nhất quán.
- Có thông báo lỗi/thành công, màn hình chờ và xác nhận trước thao tác quan trọng.
- Không tải danh sách quá dài khi không cần; có tìm kiếm/lọc theo trạng thái và khoảng ngày.
- Hóa đơn in sạch, không in menu hoặc nút thao tác.

## Tiêu chuẩn kiểm thử trước khi trả mã

1. Kiểm tra cú pháp tất cả `.gs` và JavaScript phía trình duyệt.
2. Đối chiếu mọi `google.script.run` với hàm server có thật.
3. Đối chiếu mọi `getElementById` với ID có thật trong HTML.
4. Thử số đêm: cùng ngày = 1, ngày hôm sau = 1, cách hai ngày = 2.
5. Thử một khách đặt nhiều phòng: số dòng bằng số phòng, chung mã nhóm, số khách từng phòng hợp lệ và tổng tiền cọc phân bổ không đổi.
6. Thử chặn đặt trùng, gia hạn trùng và nhận phòng khi phòng chưa sẵn sàng.
7. Thử chu trình trạng thái phòng đầy đủ.
8. Thử thêm/hủy minibar và đối chiếu tồn.
9. Thử chọn/xóa logo, lưu, mở lại cài đặt và in hóa đơn.
10. Thử giảm tiền, cọc, thu một phần, thu đủ, in hóa đơn và doanh thu.
11. Trả về đầy đủ mã nguồn, manifest, hướng dẫn cài đặt, hướng dẫn sử dụng và danh sách kiểm thử; không trả mã rời rạc hoặc bỏ sót tệp.

Bộ mới phải sử dụng khóa thuộc tính và mã phiên bản riêng, không đọc nhầm liên kết bảng tính của dự án cũ. Hàm khởi tạo phải tạo được một bảng tính sạch, đầy đủ danh mục mẫu và không yêu cầu bất kỳ trang dữ liệu cũ nào. Danh sách phòng luôn hiển thị mã, tên, tầng, loại phòng, giá hiện hành và trạng thái, kể cả khi chưa có phiếu công việc buồng phòng.
