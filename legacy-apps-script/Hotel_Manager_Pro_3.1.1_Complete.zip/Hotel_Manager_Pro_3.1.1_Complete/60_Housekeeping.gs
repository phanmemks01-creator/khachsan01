function getHmsHousekeeping() {
  return hmsObjects_(HMS.SHEETS.HOUSEKEEPING).map(function (r) {
    return {
      id: String(r.MA_CONG_VIEC || ''), createdAt: hmsDateTimeText_(r.NGAY_TAO), room: String(r.MA_PHONG || ''),
      type: String(r.LOAI_CONG_VIEC || ''), priority: String(r.MUC_DO || ''), status: String(r.TRANG_THAI || ''),
      assignee: String(r.NGUOI_NHAN || ''), startedAt: hmsDateTimeText_(r.BAT_DAU), completedAt: hmsDateTimeText_(r.HOAN_THANH),
      creator: String(r.NGUOI_TAO || ''), note: String(r.GHI_CHU || ''), rowNumber: r._rowNumber
    };
  }).filter(function (r) { return r.id; }).sort(function (a, b) { return b.id.localeCompare(a.id); });
}

function createHmsHousekeeping(data) {
  data = data || {};
  return hmsWithLock_(function () {
    const id = hmsCreateHousekeeping_(data.room, data.type || 'Vệ sinh phòng', data.priority || 'Bình thường', data.note || '');
    return { ok: true, id: id, message: 'Đã tạo công việc buồng phòng ' + id + '.' };
  });
}

function hmsCreateHousekeeping_(roomCode, type, priority, note) {
  const room = hmsRequire_(HMS.SHEETS.ROOMS, 'MA_PHONG', roomCode, 'phòng ' + roomCode);
  const existing = hmsObjects_(HMS.SHEETS.HOUSEKEEPING).filter(function (x) {
    return String(x.MA_PHONG || '') === String(roomCode) && ['Chờ xử lý', 'Đang làm'].indexOf(String(x.TRANG_THAI || '')) >= 0;
  })[0];
  if (existing) return String(existing.MA_CONG_VIEC);
  const id = hmsId_('BP');
  hmsAppend_(HMS.SHEETS.HOUSEKEEPING, {
    MA_CONG_VIEC: id, NGAY_TAO: new Date(), MA_PHONG: room.MA_PHONG, LOAI_CONG_VIEC: hmsSafe_(type) || 'Vệ sinh phòng',
    MUC_DO: hmsSafe_(priority) || 'Bình thường', TRANG_THAI: 'Chờ xử lý', NGUOI_NHAN: '', BAT_DAU: '',
    HOAN_THANH: '', NGUOI_TAO: hmsUser_(), GHI_CHU: hmsSafe_(note)
  });
  return id;
}

function startHmsHousekeeping(taskId, assignee) {
  return hmsWithLock_(function () {
    const task = hmsRequire_(HMS.SHEETS.HOUSEKEEPING, 'MA_CONG_VIEC', taskId, 'công việc buồng phòng');
    if (String(task.TRANG_THAI || '') !== 'Chờ xử lý') throw new Error('Công việc không ở trạng thái chờ xử lý.');
    hmsUpdate_(HMS.SHEETS.HOUSEKEEPING, task._rowNumber, {
      TRANG_THAI: 'Đang làm', NGUOI_NHAN: hmsSafe_(assignee) || hmsUser_(), BAT_DAU: new Date()
    });
    hmsLog_('Bắt đầu vệ sinh', 'Buồng phòng', taskId, task.MA_PHONG);
    return 'Đã bắt đầu công việc phòng ' + task.MA_PHONG + '.';
  });
}

function completeHmsHousekeeping(taskId, note) {
  return hmsWithLock_(function () {
    const task = hmsRequire_(HMS.SHEETS.HOUSEKEEPING, 'MA_CONG_VIEC', taskId, 'công việc buồng phòng');
    if (String(task.TRANG_THAI || '') === 'Hoàn thành') return 'Công việc đã hoàn thành.';
    hmsUpdate_(HMS.SHEETS.HOUSEKEEPING, task._rowNumber, {
      TRANG_THAI: 'Hoàn thành', NGUOI_NHAN: task.NGUOI_NHAN || hmsUser_(),
      BAT_DAU: task.BAT_DAU || new Date(), HOAN_THANH: new Date(), GHI_CHU: hmsSafe_(note) || task.GHI_CHU
    });
    const openMaintenance = hmsObjects_(HMS.SHEETS.MAINTENANCE).some(function (m) {
      return String(m.MA_PHONG || '') === String(task.MA_PHONG) && ['Chờ xử lý', 'Đang xử lý'].indexOf(String(m.TRANG_THAI || '')) >= 0;
    });
    if (openMaintenance) {
      const room = hmsRequire_(HMS.SHEETS.ROOMS, 'MA_PHONG', task.MA_PHONG, 'phòng');
      hmsUpdate_(HMS.SHEETS.ROOMS, room._rowNumber, { TRANG_THAI: 'Bảo trì' });
    } else {
      const room = hmsRequire_(HMS.SHEETS.ROOMS, 'MA_PHONG', task.MA_PHONG, 'phòng');
      hmsUpdate_(HMS.SHEETS.ROOMS, room._rowNumber, { TRANG_THAI: 'Phòng trống' });
      hmsRefreshRoomStatus_(task.MA_PHONG);
    }
    hmsLog_('Hoàn tất vệ sinh', 'Buồng phòng', taskId, task.MA_PHONG);
    return 'Phòng ' + task.MA_PHONG + ' đã sẵn sàng theo trạng thái mới.';
  });
}

function getHmsMaintenance() {
  return hmsObjects_(HMS.SHEETS.MAINTENANCE).map(function (r) {
    return {
      id: String(r.MA_BAO_TRI || ''), createdAt: hmsDateTimeText_(r.NGAY_TAO), room: String(r.MA_PHONG || ''),
      issue: String(r.SU_CO || ''), priority: String(r.MUC_DO || ''), status: String(r.TRANG_THAI || ''),
      assignee: String(r.NGUOI_XU_LY || ''), completedAt: hmsDateTimeText_(r.NGAY_HOAN_THANH),
      creator: String(r.NGUOI_TAO || ''), note: String(r.GHI_CHU || ''), rowNumber: r._rowNumber
    };
  }).filter(function (r) { return r.id; }).sort(function (a, b) { return b.id.localeCompare(a.id); });
}

function reportHmsMaintenance(data) {
  data = data || {};
  return hmsWithLock_(function () {
    const room = hmsRequire_(HMS.SHEETS.ROOMS, 'MA_PHONG', data.room, 'phòng ' + data.room);
    const occupied = hmsObjects_(HMS.SHEETS.STAYS).some(function (s) { return String(s.MA_PHONG) === String(room.MA_PHONG) && String(s.TRANG_THAI) === 'Đang ở'; });
    if (occupied) throw new Error('Phòng đang có khách. Hãy chuyển phòng trước khi khóa bảo trì.');
    const id = hmsId_('BT');
    hmsAppend_(HMS.SHEETS.MAINTENANCE, {
      MA_BAO_TRI: id, NGAY_TAO: new Date(), MA_PHONG: room.MA_PHONG, SU_CO: hmsSafe_(data.issue),
      MUC_DO: hmsSafe_(data.priority) || 'Bình thường', TRANG_THAI: 'Chờ xử lý', NGUOI_XU_LY: '',
      NGAY_HOAN_THANH: '', NGUOI_TAO: hmsUser_(), GHI_CHU: hmsSafe_(data.note)
    });
    hmsUpdate_(HMS.SHEETS.ROOMS, room._rowNumber, { TRANG_THAI: 'Bảo trì' });
    hmsLog_('Báo sự cố', 'Bảo trì', id, room.MA_PHONG + ' · ' + hmsSafe_(data.issue));
    return { ok: true, id: id, message: 'Đã ghi nhận sự cố phòng ' + room.MA_PHONG + '.' };
  });
}

function startHmsMaintenance(maintenanceId, assignee) {
  return hmsWithLock_(function () {
    const item = hmsRequire_(HMS.SHEETS.MAINTENANCE, 'MA_BAO_TRI', maintenanceId, 'phiếu bảo trì');
    if (String(item.TRANG_THAI || '') !== 'Chờ xử lý') throw new Error('Phiếu không ở trạng thái chờ xử lý.');
    hmsUpdate_(HMS.SHEETS.MAINTENANCE, item._rowNumber, { TRANG_THAI: 'Đang xử lý', NGUOI_XU_LY: hmsSafe_(assignee) || hmsUser_() });
    hmsLog_('Bắt đầu bảo trì', 'Bảo trì', maintenanceId, item.MA_PHONG);
    return 'Đã bắt đầu xử lý sự cố.';
  });
}

function completeHmsMaintenance(maintenanceId, note) {
  return hmsWithLock_(function () {
    const item = hmsRequire_(HMS.SHEETS.MAINTENANCE, 'MA_BAO_TRI', maintenanceId, 'phiếu bảo trì');
    if (String(item.TRANG_THAI || '') === 'Hoàn thành') return 'Phiếu đã hoàn thành.';
    hmsUpdate_(HMS.SHEETS.MAINTENANCE, item._rowNumber, {
      TRANG_THAI: 'Hoàn thành', NGUOI_XU_LY: item.NGUOI_XU_LY || hmsUser_(),
      NGAY_HOAN_THANH: new Date(), GHI_CHU: hmsSafe_(note) || item.GHI_CHU
    });
    const room = hmsRequire_(HMS.SHEETS.ROOMS, 'MA_PHONG', item.MA_PHONG, 'phòng');
    hmsUpdate_(HMS.SHEETS.ROOMS, room._rowNumber, { TRANG_THAI: 'Chờ vệ sinh' });
    hmsCreateHousekeeping_(item.MA_PHONG, 'Vệ sinh sau bảo trì', 'Ưu tiên', 'Tự động từ bảo trì');
    hmsLog_('Hoàn tất bảo trì', 'Bảo trì', maintenanceId, item.MA_PHONG);
    return 'Đã hoàn tất bảo trì; phòng chuyển sang Chờ vệ sinh.';
  });
}
