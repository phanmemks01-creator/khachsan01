/**
 * Bảo mật báo cáo tài chính bằng PIN băm SHA-256 và phiên truy cập ngắn hạn.
 * PIN ban đầu là 2468 và phải được đổi sau khi cài đặt.
 */
function ensureHmsFinanceSecurity_() {
  const props = PropertiesService.getScriptProperties();
  if (!props.getProperty('HMS_FINANCE_PIN_SALT') || !props.getProperty('HMS_FINANCE_PIN_HASH')) {
    const salt = Utilities.getUuid() + Utilities.getUuid();
    props.setProperty('HMS_FINANCE_PIN_SALT', salt);
    props.setProperty('HMS_FINANCE_PIN_HASH', hmsHashFinancePin_('2468', salt));
  }
  if (!props.getProperty('HMS_FINANCE_SECURITY_VERSION')) props.setProperty('HMS_FINANCE_SECURITY_VERSION', Utilities.getUuid());
  [
    ['KHOA_TAI_CHINH', true, 'Bảo mật tài chính', 'Yêu cầu PIN khi mở báo cáo tài chính'],
    ['PHIEN_TAI_CHINH_PHUT', 30, 'Bảo mật tài chính', 'Số phút duy trì phiên đã mở khóa'],
    ['SO_LAN_SAI_TOI_DA', 5, 'Bảo mật tài chính', 'Số lần nhập sai trước khi tạm khóa'],
    ['KHOA_TAM_PHUT', 15, 'Bảo mật tài chính', 'Số phút tạm khóa khi nhập sai quá số lần']
  ].forEach(function (row) {
    if (!hmsFind_(HMS.SHEETS.SETTINGS, 'KHOA', row[0])) {
      hmsAppend_(HMS.SHEETS.SETTINGS, { KHOA: row[0], GIA_TRI: row[1], NHOM: row[2], MO_TA: row[3] });
    }
  });
}

function hmsHashFinancePin_(pin, salt) {
  const bytes = Utilities.computeDigest(
    Utilities.DigestAlgorithm.SHA_256,
    String(salt || '') + '|' + String(pin || ''),
    Utilities.Charset.UTF_8
  );
  return bytes.map(function (b) { const n = b < 0 ? b + 256 : b; return ('0' + n.toString(16)).slice(-2); }).join('');
}

function hmsSecureEquals_(left, right) {
  left = String(left || ''); right = String(right || '');
  if (left.length !== right.length) return false;
  let diff = 0;
  for (let i = 0; i < left.length; i++) diff |= left.charCodeAt(i) ^ right.charCodeAt(i);
  return diff === 0;
}

function hmsFinanceActorKey_() {
  const source = (Session.getTemporaryActiveUserKey() || '') + '|' + hmsUser_();
  return hmsHashFinancePin_(source, 'HMS-FINANCE-ACTOR').slice(0, 32);
}

function hmsFinanceConfig_() {
  const settings = hmsSettings_();
  return {
    enabled: settings.KHOA_TAI_CHINH == null || settings.KHOA_TAI_CHINH === '' ? true : hmsBool_(settings.KHOA_TAI_CHINH),
    sessionMinutes: Math.max(5, Math.min(120, Math.round(hmsNumber_(settings.PHIEN_TAI_CHINH_PHUT, 30)))),
    maxAttempts: Math.max(3, Math.min(10, Math.round(hmsNumber_(settings.SO_LAN_SAI_TOI_DA, 5)))),
    lockMinutes: Math.max(5, Math.min(60, Math.round(hmsNumber_(settings.KHOA_TAM_PHUT, 15))))
  };
}

function getHmsFinanceStatus() {
  const config = hmsFinanceConfig_();
  return { enabled: config.enabled, sessionMinutes: config.sessionMinutes, pinConfigured: !!PropertiesService.getScriptProperties().getProperty('HMS_FINANCE_PIN_HASH') };
}

function verifyHmsFinancePin(pin) {
  ensureHmsFinanceSecurity_();
  const config = hmsFinanceConfig_();
  const cache = CacheService.getScriptCache();
  const actor = hmsFinanceActorKey_();
  const attemptKey = 'HMS_FIN_ATTEMPT_' + actor;
  const now = new Date().getTime();
  let attempts = {};
  try { attempts = JSON.parse(cache.get(attemptKey) || '{}'); } catch (ignore) { attempts = {}; }
  if (attempts.lockedUntil && now < attempts.lockedUntil) {
    const wait = Math.ceil((attempts.lockedUntil - now) / 60000);
    throw new Error('Mục Tài chính đang tạm khóa. Vui lòng thử lại sau ' + wait + ' phút.');
  }
  if (config.enabled) {
    const props = PropertiesService.getScriptProperties();
    const actual = hmsHashFinancePin_(String(pin || ''), props.getProperty('HMS_FINANCE_PIN_SALT'));
    if (!hmsSecureEquals_(actual, props.getProperty('HMS_FINANCE_PIN_HASH'))) {
      const count = Math.max(0, Number(attempts.count || 0)) + 1;
      if (count >= config.maxAttempts) {
        cache.put(attemptKey, JSON.stringify({ count: count, lockedUntil: now + config.lockMinutes * 60000 }), config.lockMinutes * 60);
        hmsLog_('Khóa tạm tài chính', 'Bảo mật', actor, 'Nhập sai PIN ' + count + ' lần');
        throw new Error('Nhập sai quá số lần cho phép. Tài chính đã tạm khóa ' + config.lockMinutes + ' phút.');
      }
      cache.put(attemptKey, JSON.stringify({ count: count }), config.lockMinutes * 60);
      throw new Error('Mã PIN không đúng. Còn ' + (config.maxAttempts - count) + ' lần thử.');
    }
  }
  cache.remove(attemptKey);
  const token = Utilities.getUuid().replace(/-/g, '') + Utilities.getUuid().replace(/-/g, '');
  const securityVersion = PropertiesService.getScriptProperties().getProperty('HMS_FINANCE_SECURITY_VERSION') || '';
  cache.put('HMS_FIN_TOKEN_' + token, actor + '|' + securityVersion, config.sessionMinutes * 60);
  hmsLog_('Mở khóa tài chính', 'Bảo mật', actor, 'Phiên ' + config.sessionMinutes + ' phút');
  return { ok: true, token: token, sessionMinutes: config.sessionMinutes };
}

function hmsRequireFinanceToken_(token) {
  const config = hmsFinanceConfig_();
  if (!config.enabled) return true;
  const actor = hmsFinanceActorKey_();
  const saved = token ? CacheService.getScriptCache().get('HMS_FIN_TOKEN_' + String(token)) : '';
  const securityVersion = PropertiesService.getScriptProperties().getProperty('HMS_FINANCE_SECURITY_VERSION') || '';
  if (!saved || saved !== actor + '|' + securityVersion) throw new Error('Phiên Tài chính chưa được mở khóa hoặc đã hết hạn.');
  return true;
}

function saveHmsFinanceSecurity(data) {
  data = data || {};
  ensureHmsFinanceSecurity_();
  const currentPin = String(data.currentPin || '');
  const props = PropertiesService.getScriptProperties();
  const actual = hmsHashFinancePin_(currentPin, props.getProperty('HMS_FINANCE_PIN_SALT'));
  if (!hmsSecureEquals_(actual, props.getProperty('HMS_FINANCE_PIN_HASH'))) throw new Error('Mã PIN hiện tại không đúng.');
  const newPin = String(data.newPin || '').trim();
  if (newPin && !/^\d{4,8}$/.test(newPin)) throw new Error('PIN mới phải gồm 4–8 chữ số.');
  return hmsWithLock_(function () {
    if (newPin) {
      const salt = Utilities.getUuid() + Utilities.getUuid();
      props.setProperty('HMS_FINANCE_PIN_SALT', salt);
      props.setProperty('HMS_FINANCE_PIN_HASH', hmsHashFinancePin_(newPin, salt));
    }
    const enabled = data.enabled !== false;
    const minutes = Math.max(5, Math.min(120, Math.round(hmsNumber_(data.sessionMinutes, 30))));
    hmsUpsert_(HMS.SHEETS.SETTINGS, 'KHOA', 'KHOA_TAI_CHINH', { KHOA: 'KHOA_TAI_CHINH', GIA_TRI: enabled, NHOM: 'Bảo mật tài chính', MO_TA: 'Yêu cầu PIN khi mở báo cáo tài chính' });
    hmsUpsert_(HMS.SHEETS.SETTINGS, 'KHOA', 'PHIEN_TAI_CHINH_PHUT', { KHOA: 'PHIEN_TAI_CHINH_PHUT', GIA_TRI: minutes, NHOM: 'Bảo mật tài chính', MO_TA: 'Số phút duy trì phiên đã mở khóa' });
    props.setProperty('HMS_FINANCE_SECURITY_VERSION', Utilities.getUuid());
    hmsLog_('Cập nhật bảo mật tài chính', 'Bảo mật', hmsFinanceActorKey_(), 'Khóa: ' + enabled + ' · phiên: ' + minutes + ' phút' + (newPin ? ' · đã đổi PIN' : ''));
    return { ok: true, message: 'Đã cập nhật bảo mật tài chính.', enabled: enabled, sessionMinutes: minutes };
  });
}
