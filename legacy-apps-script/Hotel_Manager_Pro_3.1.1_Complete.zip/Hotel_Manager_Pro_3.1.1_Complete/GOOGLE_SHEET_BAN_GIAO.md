# GOOGLE SHEET DỮ LIỆU HOTEL MANAGER PRO 3.1

Bảng tính đã tạo và dùng làm liên kết dự phòng cho Web App:

https://docs.google.com/spreadsheets/d/1qHh8TiVdacFTDDxqje9XdxIktSgfvlQHpYN_NjUgzr4/edit?usp=drivesdk

ID bảng tính:

`1qHh8TiVdacFTDDxqje9XdxIktSgfvlQHpYN_NjUgzr4`

Bộ mã 3.1.1 ưu tiên `HMS3_SPREADSHEET_ID` của dự án. Nếu thuộc tính này chưa có và dự án không gắn trực tiếp vào một Google Sheet, hệ thống sẽ dùng ID trên.
