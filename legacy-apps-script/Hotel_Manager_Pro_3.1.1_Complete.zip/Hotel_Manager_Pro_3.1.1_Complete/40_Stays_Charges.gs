function getHmsStays() {
  return hmsObjects_(HMS.SHEETS.STAYS).map(function (r) {
    const checkIn = hmsDate_(r.NHAN_PHONG), expected = hmsDate_(r.TRA_DU_KIEN), checkout = hmsDate_(r.TRA_PHONG);
    return {
      id: String(r.MA_LUU_TRU || ''), bookingId: String(r.MA_DAT_PHONG || ''), room: String(r.MA_PHONG || ''),
      roomType: String(r.LOAI_PHONG || ''), rateCode: String(r.MA_GIA || ''), guestId: String(r.MA_KHACH || ''),
      guestName: String(r.TEN_KHACH || ''), phone: String(r.SDT || ''), guestCount: hmsNumber_(r.SO_NGUOI, 1),
      checkIn: hmsDateTimeInput_(checkIn), expectedCheckout: hmsDateTimeInput_(expected), checkout: hmsDateTimeInput_(checkout),
      checkInText: hmsDateTimeText_(checkIn), expectedCheckoutText: hmsDateTimeText_(expected), checkoutText: hmsDateTimeText_(checkout),
      checkInValue: checkIn ? checkIn.getTime() : 0, expectedCheckoutValue: expected ? expected.getTime() : 0,
      nights: hmsNumber_(r.SO_DEM, checkIn && (checkout || expected) ? hmsNights_(checkIn, checkout || expected) : 0),
      averageRate: hmsMoney_(r.DON_GIA_BINH_QUAN), roomAmount: hmsMoney_(r.TIEN_PHONG), surcharge: hmsMoney_(r.PHU_THU),
      deposit: hmsMoney_(r.TIEN_COC), status: String(r.TRANG_THAI || ''), receiver: String(r.NGUOI_NHAN || ''),
      note: String(r.GHI_CHU || ''), rowNumber: r._rowNumber
    };
  }).filter(function (r) { return r.id; }).sort(function (a, b) { return b.checkInValue - a.checkInValue; });
}

function extendHmsStay(stayId, newExpectedCheckout, note) {
  return hmsWithLock_(function () {
    const stay = hmsRequire_(HMS.SHEETS.STAYS, 'MA_LUU_TRU', stayId, 'lưu trú');
    if (String(stay.TRANG_THAI || '') !== 'Đang ở') throw new Error('Chỉ gia hạn được hồ sơ đang lưu trú.');
    const next = hmsDate_(newExpectedCheckout);
    const checkIn = hmsDate_(stay.NHAN_PHONG), old = hmsDate_(stay.TRA_DU_KIEN);
    if (!next || next <= checkIn) throw new Error('Ngày trả dự kiến mới không hợp lệ.');
    if (old && next <= old) throw new Error('Ngày gia hạn phải sau ngày trả dự kiến hiện tại.');
    hmsAssertRoomAvailable_(stay.MA_PHONG, checkIn, next, stay.MA_DAT_PHONG, stay.MA_LUU_TRU);
    hmsUpdate_(HMS.SHEETS.STAYS, stay._rowNumber, { TRA_DU_KIEN: next, GHI_CHU: hmsSafe_(note) || stay.GHI_CHU });
    const booking = hmsFind_(HMS.SHEETS.BOOKINGS, 'MA_DAT_PHONG', stay.MA_DAT_PHONG);
    if (booking) hmsUpdate_(HMS.SHEETS.BOOKINGS, booking._rowNumber, { TRA_DU_KIEN: next, SO_DEM_DU_KIEN: hmsNights_(booking.NHAN_DU_KIEN, next) });
    hmsLog_('Gia hạn lưu trú', 'Lưu trú', stay.MA_LUU_TRU, hmsDateTimeText_(old) + ' → ' + hmsDateTimeText_(next));
    return 'Đã gia hạn phòng ' + stay.MA_PHONG + ' đến ' + hmsDateTimeText_(next) + '.';
  });
}

function moveHmsStay(stayId, newRoomCode, moveTime, surcharge, reason) {
  return hmsWithLock_(function () {
    const stay = hmsRequire_(HMS.SHEETS.STAYS, 'MA_LUU_TRU', stayId, 'lưu trú');
    if (String(stay.TRANG_THAI || '') !== 'Đang ở') throw new Error('Chỉ chuyển phòng cho khách đang lưu trú.');
    const oldRoomCode = String(stay.MA_PHONG || '');
    const target = hmsSafe_(newRoomCode).toUpperCase();
    if (!target || target === oldRoomCode) throw new Error('Vui lòng chọn phòng mới khác phòng hiện tại.');
    const room = hmsRequire_(HMS.SHEETS.ROOMS, 'MA_PHONG', target, 'phòng ' + target);
    if (!hmsActive_(room.HOAT_DONG) || ['Đang ở', 'Chờ vệ sinh', 'Bảo trì', 'Tạm khóa'].indexOf(String(room.TRANG_THAI || '')) >= 0) throw new Error('Phòng mới chưa sẵn sàng.');
    if (hmsNumber_(stay.SO_NGUOI, 1) > hmsNumber_(room.SUC_CHUA, 1)) throw new Error('Phòng mới không đủ sức chứa.');
    const at = hmsDate_(moveTime) || new Date();
    const expected = hmsDate_(stay.TRA_DU_KIEN) || new Date(at.getTime() + 86400000);
    hmsAssertRoomAvailable_(target, at, expected, '', stay.MA_LUU_TRU);
    const rate = hmsResolveRate_(room.LOAI_PHONG, at, '');
    hmsUpdate_(HMS.SHEETS.STAYS, stay._rowNumber, {
      MA_PHONG: target, LOAI_PHONG: room.LOAI_PHONG, MA_GIA: rate.code,
      DON_GIA_BINH_QUAN: rate.price, PHU_THU: hmsMoney_(stay.PHU_THU) + hmsMoney_(surcharge)
    });
    const booking = hmsFind_(HMS.SHEETS.BOOKINGS, 'MA_DAT_PHONG', stay.MA_DAT_PHONG);
    if (booking) hmsUpdate_(HMS.SHEETS.BOOKINGS, booking._rowNumber, { MA_PHONG: target, LOAI_PHONG: room.LOAI_PHONG, MA_GIA: rate.code, DON_GIA_DU_KIEN: rate.price });
    const oldRoom = hmsRequire_(HMS.SHEETS.ROOMS, 'MA_PHONG', oldRoomCode, 'phòng cũ');
    hmsUpdate_(HMS.SHEETS.ROOMS, oldRoom._rowNumber, { TRANG_THAI: 'Chờ vệ sinh' });
    hmsUpdate_(HMS.SHEETS.ROOMS, room._rowNumber, { TRANG_THAI: 'Đang ở' });
    const moveId = hmsId_('CP');
    hmsAppend_(HMS.SHEETS.MOVES, {
      MA_CHUYEN: moveId, THOI_GIAN: at, MA_LUU_TRU: stay.MA_LUU_TRU, PHONG_CU: oldRoomCode,
      PHONG_MOI: target, DON_GIA_CU: hmsMoney_(stay.DON_GIA_BINH_QUAN), DON_GIA_MOI: rate.price,
      PHU_THU: hmsMoney_(surcharge), LY_DO: hmsSafe_(reason), NGUOI_THUC_HIEN: hmsUser_()
    });
    hmsCreateHousekeeping_(oldRoomCode, 'Vệ sinh sau chuyển phòng', 'Bình thường', 'Tự động từ chuyển phòng');
    hmsLog_('Chuyển phòng', 'Lưu trú', stay.MA_LUU_TRU, oldRoomCode + ' → ' + target);
    return 'Đã chuyển khách từ phòng ' + oldRoomCode + ' sang ' + target + '.';
  });
}

function getHmsCharges(stayId) {
  return hmsObjects_(HMS.SHEETS.CHARGES).filter(function (r) { return !stayId || String(r.MA_LUU_TRU || '') === String(stayId); }).map(function (r) {
    return {
      id: String(r.MA_PHAT_SINH || ''), at: hmsDateTimeText_(r.THOI_GIAN), stayId: String(r.MA_LUU_TRU || ''),
      room: String(r.MA_PHONG || ''), type: String(r.LOAI || ''), code: String(r.MA_DICH_VU || ''),
      name: String(r.TEN_DICH_VU || ''), unit: String(r.DON_VI || ''), quantity: hmsNumber_(r.SO_LUONG, 0),
      price: hmsMoney_(r.DON_GIA), amount: hmsMoney_(r.THANH_TIEN), status: String(r.TRANG_THAI || ''),
      invoiceId: String(r.MA_HOA_DON || ''), creator: String(r.NGUOI_TAO || ''), note: String(r.GHI_CHU || ''), rowNumber: r._rowNumber
    };
  }).filter(function (r) { return r.id; });
}

function addHmsCharge(data) {
  data = data || {};
  return hmsWithLock_(function () {
    const stay = hmsRequire_(HMS.SHEETS.STAYS, 'MA_LUU_TRU', data.stayId, 'lưu trú');
    if (String(stay.TRANG_THAI || '') !== 'Đang ở') throw new Error('Chỉ thêm phát sinh cho khách đang lưu trú.');
    const service = hmsRequire_(HMS.SHEETS.SERVICES, 'MA_DICH_VU', data.serviceCode, 'nước uống/dịch vụ');
    if (!hmsActive_(service.HOAT_DONG)) throw new Error('Dịch vụ đã ngừng hoạt động.');
    const quantity = Math.max(1, hmsNumber_(data.quantity, 1));
    if (hmsBool_(service.THEO_DOI_TON)) hmsAdjustStock_(service.MA_DICH_VU, -quantity, 'Xuất cho khách', stay.MA_LUU_TRU);
    const id = hmsId_('PS');
    hmsAppend_(HMS.SHEETS.CHARGES, {
      MA_PHAT_SINH: id, THOI_GIAN: new Date(), MA_LUU_TRU: stay.MA_LUU_TRU, MA_PHONG: stay.MA_PHONG,
      LOAI: service.LOAI, MA_DICH_VU: service.MA_DICH_VU, TEN_DICH_VU: service.TEN_DICH_VU, DON_VI: service.DON_VI,
      SO_LUONG: quantity, DON_GIA: hmsMoney_(service.DON_GIA), THANH_TIEN: hmsMoney_(service.DON_GIA) * quantity,
      TRANG_THAI: 'Đã ghi nhận', MA_HOA_DON: '', NGUOI_TAO: hmsUser_(), GHI_CHU: hmsSafe_(data.note)
    });
    hmsLog_('Thêm phát sinh', 'Lưu trú', stay.MA_LUU_TRU, service.TEN_DICH_VU + ' × ' + quantity);
    return 'Đã thêm ' + service.TEN_DICH_VU + ' cho phòng ' + stay.MA_PHONG + '.';
  });
}

function cancelHmsCharge(chargeId, note) {
  return hmsWithLock_(function () {
    const charge = hmsRequire_(HMS.SHEETS.CHARGES, 'MA_PHAT_SINH', chargeId, 'phát sinh');
    if (String(charge.TRANG_THAI || '') !== 'Đã ghi nhận' || charge.MA_HOA_DON) throw new Error('Phát sinh đã lên hóa đơn hoặc đã hủy.');
    const service = hmsFind_(HMS.SHEETS.SERVICES, 'MA_DICH_VU', charge.MA_DICH_VU);
    if (service && hmsBool_(service.THEO_DOI_TON)) hmsAdjustStock_(service.MA_DICH_VU, hmsNumber_(charge.SO_LUONG, 0), 'Hoàn do hủy phát sinh', charge.MA_LUU_TRU);
    hmsUpdate_(HMS.SHEETS.CHARGES, charge._rowNumber, { TRANG_THAI: 'Đã hủy', GHI_CHU: hmsSafe_(note) || charge.GHI_CHU });
    hmsLog_('Hủy phát sinh', 'Phát sinh', charge.MA_PHAT_SINH, charge.TEN_DICH_VU);
    return 'Đã hủy phát sinh ' + charge.MA_PHAT_SINH + '.';
  });
}

function receiveHmsStock(data) {
  data = data || {};
  return hmsWithLock_(function () {
    const service = hmsRequire_(HMS.SHEETS.SERVICES, 'MA_DICH_VU', data.serviceCode, 'mặt hàng');
    if (!hmsBool_(service.THEO_DOI_TON)) throw new Error('Mặt hàng này không theo dõi tồn kho.');
    const quantity = Math.max(0, hmsNumber_(data.quantity, 0));
    if (!quantity) throw new Error('Số lượng nhập phải lớn hơn 0.');
    const id = hmsId_('NK');
    hmsAppend_(HMS.SHEETS.STOCK_IN, {
      MA_PHIEU_NHAP: id, THOI_GIAN: new Date(), MA_DICH_VU: service.MA_DICH_VU, TEN_HANG: service.TEN_DICH_VU,
      SO_LUONG: quantity, DON_GIA_NHAP: hmsMoney_(data.unitCost), THANH_TIEN: quantity * hmsMoney_(data.unitCost),
      NHA_CUNG_CAP: hmsSafe_(data.supplier), NGUOI_NHAP: hmsUser_(), GHI_CHU: hmsSafe_(data.note)
    });
    hmsAdjustStock_(service.MA_DICH_VU, quantity, 'Nhập kho', '');
    hmsLog_('Nhập kho', 'Kho minibar', service.MA_DICH_VU, String(quantity));
    return 'Đã nhập ' + quantity + ' ' + service.DON_VI + ' ' + service.TEN_DICH_VU + '.';
  });
}

function hmsAdjustStock_(serviceCode, delta, reason, stayId) {
  const service = hmsRequire_(HMS.SHEETS.SERVICES, 'MA_DICH_VU', serviceCode, 'mặt hàng');
  let stock = hmsFind_(HMS.SHEETS.STOCK, 'MA_DICH_VU', serviceCode);
  if (!stock) {
    hmsAppend_(HMS.SHEETS.STOCK, {
      MA_DICH_VU: serviceCode, TEN_HANG: service.TEN_DICH_VU, DON_VI: service.DON_VI,
      TON_DAU: 0, TONG_NHAP: 0, TONG_XUAT: 0, TON_HIEN_TAI: 0,
      TON_TOI_THIEU: hmsNumber_(service.TON_TOI_THIEU, 0), TRANG_THAI: 'Sắp hết', CAP_NHAT_CUOI: new Date()
    });
    stock = hmsFind_(HMS.SHEETS.STOCK, 'MA_DICH_VU', serviceCode);
  }
  const current = hmsNumber_(stock.TON_HIEN_TAI, 0);
  const next = current + hmsNumber_(delta, 0);
  if (next < 0) throw new Error('Không đủ tồn kho ' + service.TEN_DICH_VU + '. Hiện còn ' + current + '.');
  const totalIn = hmsNumber_(stock.TONG_NHAP, 0) + (delta > 0 ? delta : 0);
  const totalOut = hmsNumber_(stock.TONG_XUAT, 0) + (delta < 0 ? Math.abs(delta) : 0);
  const min = hmsNumber_(stock.TON_TOI_THIEU || service.TON_TOI_THIEU, 0);
  hmsUpdate_(HMS.SHEETS.STOCK, stock._rowNumber, {
    TONG_NHAP: totalIn, TONG_XUAT: totalOut, TON_HIEN_TAI: next,
    TRANG_THAI: next <= min ? 'Sắp hết' : 'Đủ hàng', CAP_NHAT_CUOI: new Date()
  });
  if (delta < 0) hmsAppend_(HMS.SHEETS.STOCK_OUT, {
    MA_PHIEU_XUAT: hmsId_('XK'), THOI_GIAN: new Date(), MA_DICH_VU: serviceCode, TEN_HANG: service.TEN_DICH_VU,
    SO_LUONG: Math.abs(delta), LY_DO: reason, MA_LUU_TRU: stayId || '', NGUOI_XUAT: hmsUser_(), GHI_CHU: ''
  });
}
