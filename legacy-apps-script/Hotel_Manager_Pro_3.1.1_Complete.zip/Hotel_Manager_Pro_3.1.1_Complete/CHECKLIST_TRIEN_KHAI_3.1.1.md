# CHECKLIST TRIỂN KHAI HOTEL MANAGER PRO 3.1.1

Thực hiện đúng thứ tự sau để Web App không tiếp tục dùng mã cũ.

## 1. Thay toàn bộ mã

- Xóa hoặc thay nội dung của tất cả tệp cũ trong dự án Apps Script.
- Tạo đủ **11 tệp `.gs`**, **3 tệp HTML** và thay đúng `appsscript.json` từ gói này.
- Không chỉ thay riêng `Index.html` hoặc `90_Client.html`.
- Lưu tất cả tệp.

## 2. Liên kết và kiểm tra bảng tính

Chạy lần lượt trong trình soạn thảo Apps Script:

```javascript
repairHotelManagerConnection()
getHmsServerStatus()
runHotelHealthCheck()
```

Kết quả `getHmsServerStatus()` hợp lệ:

- `ok: true`
- `version: 3.1.1`
- `spreadsheetId: 1qHh8TiVdacFTDDxqje9XdxIktSgfvlQHpYN_NjUgzr4` nếu dùng bảng tính bàn giao
- `missingSheets: []`

Nếu dự án đang liên kết nhầm bảng tính, chạy:

```javascript
linkHotelManagerToDefaultSpreadsheet()
```

## 3. Triển khai Web App mới

1. Chọn **Deploy → Manage deployments**.
2. Chọn biểu tượng sửa của Web App hiện tại.
3. Tại Version, chọn **New version**.
4. Nhấn **Deploy**.
5. Mở URL triển khai được Google hiển thị, đóng tab Web App cũ và tải lại trang.

Chỉ nhấn **Save** trong trình soạn thảo không làm Web App hiện tại nhận mã mới.

## 4. Dấu hiệu đã cập nhật đúng

- Thanh bên hiển thị `HOTEL MANAGER PRO 3.1.1`.
- Chân menu hiển thị `Phiên bản 3.1.1` sau khi tải xong.
- Dashboard có dữ liệu, không còn thông báo “Máy chủ không trả dữ liệu”.

## 5. Nếu vẫn có lỗi

Mở **Executions** trong Apps Script, chọn lần chạy lỗi mới nhất và sao chép nguyên văn thông báo lỗi. Đồng thời chạy lại `getHmsServerStatus()` để biết chính xác ID bảng tính và trang còn thiếu.
