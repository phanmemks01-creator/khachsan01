/**
 * Chẩn đoán kết nối chỉ trả về chuỗi, số, boolean và mảng chuỗi.
 * Có thể chạy trực tiếp trong Apps Script trước khi triển khai Web App.
 */
function getHmsServerStatus() {
  const result = {
    ok: false,
    version: HMS.VERSION,
    spreadsheetId: '',
    spreadsheetName: '',
    sheetCount: 0,
    missingSheets: [],
    setupVersion: PropertiesService.getScriptProperties().getProperty('HMS3_VERSION') || '',
    checkedAt: hmsDateTimeText_(new Date()),
    error: ''
  };
  try {
    const ss = hmsSpreadsheet_();
    const names = ss.getSheets().map(function (sheet) { return sheet.getName(); });
    result.spreadsheetId = String(ss.getId() || '');
    result.spreadsheetName = String(ss.getName() || '');
    result.sheetCount = names.length;
    result.missingSheets = Object.keys(HMS.SHEETS).map(function (key) { return HMS.SHEETS[key]; })
      .filter(function (name) { return names.indexOf(name) < 0; });
    result.ok = result.missingSheets.length === 0;
  } catch (error) {
    result.error = String(error && error.message ? error.message : error || 'Không xác định được trạng thái máy chủ.');
  }
  return hmsJsonSafe_(result);
}

/**
 * Liên kết lại dự án với bảng tính đang mở; nếu chạy từ Web App độc lập thì dùng
 * bảng tính mặc định đi kèm bộ mã. Sau đó hoàn thiện toàn bộ cấu trúc.
 */
function repairHotelManagerConnection() {
  const active = SpreadsheetApp.getActiveSpreadsheet();
  const spreadsheetId = active ? active.getId() : HMS.DEFAULT_SPREADSHEET_ID;
  if (!spreadsheetId) throw new Error('Không có bảng tính để liên kết.');
  const props = PropertiesService.getScriptProperties();
  props.setProperty('HMS3_SPREADSHEET_ID', spreadsheetId);
  HMS_RUNTIME_.spreadsheet = null;
  HMS_RUNTIME_.sheets = {};
  HMS_RUNTIME_.headers = {};
  HMS_RUNTIME_.objects = {};
  HMS_RUNTIME_.indexes = {};
  setupHotelManager_();
  const status = getHmsServerStatus();
  if (!status.ok) throw new Error(status.error || 'Kết nối chưa hoàn tất.');
  return status;
}

/** Dùng khi muốn buộc dự án độc lập quay về đúng bảng tính được bàn giao. */
function linkHotelManagerToDefaultSpreadsheet() {
  if (!HMS.DEFAULT_SPREADSHEET_ID) throw new Error('Chưa khai báo bảng tính mặc định.');
  PropertiesService.getScriptProperties().setProperty('HMS3_SPREADSHEET_ID', HMS.DEFAULT_SPREADSHEET_ID);
  HMS_RUNTIME_.spreadsheet = null;
  HMS_RUNTIME_.sheets = {};
  HMS_RUNTIME_.headers = {};
  HMS_RUNTIME_.objects = {};
  HMS_RUNTIME_.indexes = {};
  setupHotelManager_();
  return getHmsServerStatus();
}
