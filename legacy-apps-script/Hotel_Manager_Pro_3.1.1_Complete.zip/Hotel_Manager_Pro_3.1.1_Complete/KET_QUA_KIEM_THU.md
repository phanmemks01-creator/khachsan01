# KẾT QUẢ KIỂM THỬ — HOTEL MANAGER PRO 3.1.1

Ngày kiểm thử: 02/09/2026  
Múi giờ vận hành: Việt Nam (Asia/Ho_Chi_Minh)

## Phạm vi đã kiểm tra

- Cú pháp của 11 tệp Google Apps Script: đạt.
- Cú pháp JavaScript phía giao diện: đạt.
- 33 lời gọi từ giao diện đến máy chủ: đều có hàm xử lý tương ứng.
- 131 hàm máy chủ và 99 hàm khai báo phía giao diện được nhận diện.
- Tất cả ID phần tử và hàm xử lý sự kiện tĩnh trên giao diện: đầy đủ.
- Công thức tính số đêm: cùng ngày = 1 đêm; qua một ngày = 1 đêm; qua hai ngày = 2 đêm.
- Không còn mô hình bán theo chỗ ngủ; hệ thống chỉ bán nguyên phòng.
- Bảng tính gồm đủ 21 trang nghiệp vụ, bảng dữ liệu gốc, bộ lọc, danh sách chọn và định dạng số/ngày/tiền.
- Công thức hóa đơn, công nợ, doanh thu và Dashboard: không phát hiện lỗi công thức trong bản dựng.
- Hai biểu đồ native: “Doanh thu theo ngày” và “Cơ cấu trạng thái phòng”.
- Google Sheet đích: locale Việt Nam, múi giờ Việt Nam, dữ liệu mẫu và công thức đã được xác minh sau khi chuyển đổi.
- Báo cáo Tài chính bắt buộc có token phiên hợp lệ khi bật khóa; PIN được băm SHA-256 với salt riêng.
- Danh mục đồ giải khát có giá nhập, giá bán, theo dõi tồn và doanh thu riêng trong báo cáo.
- Bảng phòng trực quan đọc đồng thời phòng, lịch đặt và lưu trú để phân loại phòng có thể chọn, đang có khách, đã đặt, chờ vệ sinh hoặc khóa.
- Cách tìm thứ nhất chỉ hiện gợi ý sau khi gõ mã/tên/tầng/loại phòng và hiển thị toàn bộ kết quả phù hợp trong vùng cuộn.
- Ô `Phòng còn trống` được đổi trực tiếp thành combobox gõ–chọn; tìm không dấu theo mã, tên, tầng và loại phòng, hiển thị toàn bộ kết quả phù hợp trong vùng cuộn.
- Chỉ gõ chữ nhưng chưa chọn phòng cụ thể sẽ bị chặn trước khi lưu hoặc nhận phòng ngay.
- Cách tìm thứ hai lọc kết hợp tầng, loại phòng động từ `DM_PHONG`, sức chứa và tình trạng theo lịch rồi chọn trực tiếp trên thẻ phòng.
- Từng loại phòng hiển thị số còn trống/tổng số và có thể nhấn trực tiếp để áp dụng bộ lọc loại phòng.
- Danh sách đặt phòng lọc được theo từ khóa không dấu, khoảng ngày và trạng thái; dữ liệu hiện có trong `DAT_PHONG` tiếp tục được sử dụng.
- Một khách có thể chọn nhiều phòng trong một lần; phòng đã chọn bị loại khỏi gợi ý, có số khách riêng và không vượt sức chứa.
- Mỗi phòng được lưu thành một dòng có mã phiếu riêng và chung `MA_NHOM_DAT`; danh sách hiển thị đúng số dòng bằng số phòng đã đặt.
- Tổng tiền cọc nhóm được phân bổ theo giá dự kiến; phép thử 1.300.000 đồng cho hai trọng số 500.000/800.000 cho kết quả 500.000/800.000 và tổng không đổi.
- Logo nhận tệp PNG/JPG/WebP tối đa 5 MB, xem trước/xóa được, tự thu nhỏ tối đa 420 px và giới hạn chuỗi dữ liệu không quá 44.000 ký tự trước khi lưu.
- Trang Buồng phòng có danh sách lấy trực tiếp từ `DM_PHONG`, không phụ thuộc `BUONG_PHONG` đã có phiếu hay chưa; có tìm kiếm, lọc tầng, trạng thái, giá phòng và thao tác vệ sinh.
- Cột `HOAT_DONG` cũ để trống được hiểu là đang hoạt động; chỉ giá trị tắt rõ ràng mới ẩn phòng khỏi nghiệp vụ đặt phòng.
- Bộ mới dùng `HOTEL_MANAGER_PRO_V3`, `HMS3_SPREADSHEET_ID` và `HMS3_VERSION`, không sử dụng liên kết bảng tính hoặc phiên bản của bộ cũ.
- Hàm `setupHotelManager_()` chỉ tạo cấu trúc mới và dữ liệu mẫu; không gọi quy trình nhập/chuyển dữ liệu cũ.
- Hàm `getHmsBootstrapSafe()` và kiểm tra phía giao diện chặn lỗi đọc `version` từ dữ liệu `null`, đồng thời trả đúng thông báo lỗi khởi tạo.
- Hàm khởi động không còn gọi cài đặt/định dạng nặng mỗi lần đổi phiên bản; chỉ chạy setup đầy đủ khi thiếu trang.
- Web App độc lập có thể mở bảng tính dự phòng theo ID đã bàn giao nếu chưa có `HMS3_SPREADSHEET_ID`.
- `getHmsServerStatus()`, `repairHotelManagerConnection()` và `linkHotelManagerToDefaultSpreadsheet()` trả chẩn đoán kết nối bằng dữ liệu JSON thuần.
- Kiểm thử tự động tổng hợp đạt 35/35 điều kiện; phép thử mô phỏng xác nhận tự bỏ ID liên kết hỏng và mở đúng bảng tính dự phòng.
- Phép thử tuần tự hóa xác nhận ngày giờ được đổi thành chuỗi ISO, `undefined` thành chuỗi rỗng và `NaN/Infinity` thành `0` trước khi trả cho `google.script.run`.
- Cài đặt có bảng **Danh sách tên phòng và giá hiện hành**, cho sửa lại tên phòng hoặc bảng giá trực tiếp.
- So sánh tự động với bản 3.0.0 xác nhận: đủ 21/21 trang, toàn bộ danh sách cột giống nhau, hàng tiêu đề/dữ liệu không đổi, không mất hàm máy chủ cũ, không mất hàm giao diện cũ, toàn bộ ID giao diện và tệp định dạng giữ nguyên.
- Lớp đọc dữ liệu theo lượt xử lý, chỉ mục tra cứu, ghi theo lô, lưu cài đặt theo lô và gói khởi động một lần đều đạt kiểm tra tĩnh.
- Luồng tìm phòng đã chuyển từ quét toàn bộ đặt phòng/lưu trú cho từng phòng sang lập chỉ mục theo mã phòng một lần.
- Cột `HOAT_DONG` để trống được hiểu là đang hoạt động nhất quán cho phòng, bảng giá và dịch vụ.
- Mã chứng từ mới giữ nguyên cấu trúc tiền tố–thời gian–số, tăng phần số ngẫu nhiên lên sáu chữ số để giảm nguy cơ trùng khi đặt nhiều phòng cùng lúc.

## Luồng nghiệp vụ trọng yếu đã đối chiếu

1. Tìm phòng bằng hai cách, lọc loại phòng và chặn trùng lịch.
2. Đặt một hoặc nhiều phòng cho cùng khách, phân bổ cọc, nhận từng phòng hoặc mở nhiều phòng trực tiếp.
3. Gia hạn hoặc chuyển phòng, lưu lịch sử và đơn giá theo từng giai đoạn.
4. Ghi đồ giải khát/dịch vụ/phụ thu, tự trừ tồn kho với mặt hàng theo dõi kho.
5. Trả phòng, tính tiền phòng theo số đêm, tạo hóa đơn và chuyển phòng sang chờ vệ sinh.
6. Giảm tiền có lý do, phí dịch vụ, VAT, cấn cọc, thanh toán nhiều lần/nhiều phương thức.
7. Ghi nhận công nợ, tiền thừa và hoàn tiền thừa.
8. Hoàn tất vệ sinh, xử lý bảo trì và chỉ mở lại phòng khi an toàn.
9. Mở khóa Tài chính và báo cáo doanh thu từ ngày đến ngày, theo phòng, loại phòng và phương thức.

## Lưu ý triển khai

Google Apps Script cần được chủ sở hữu bảng tính cấp quyền ở lần chạy đầu. Sau khi sao chép mã nguồn, chạy `setupHotelManager()` một lần rồi tải lại bảng tính. Trước khi dùng thật, nên chạy một ca thử từ đặt phòng đến in hóa đơn bằng dữ liệu mẫu của khách sạn.
