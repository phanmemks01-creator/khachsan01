function doGet() {
  return HtmlService.createTemplateFromFile('Index').evaluate()
    .setTitle('Hotel Manager Pro 3.1.1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

function onOpen() {
  SpreadsheetApp.getUi().createMenu('🏨 HOTEL MANAGER PRO 3.1.1')
    .addItem('Mở phần mềm', 'showHotelManager')
    .addItem('Khởi tạo / sửa cấu trúc', 'setupHotelManager')
    .addItem('Sửa kết nối máy chủ', 'repairHotelManagerConnection')
    .addItem('Kiểm tra hệ thống', 'runHotelHealthCheck')
    .addSeparator()
    .addItem('Tạo bảng tính khách sạn mới', 'createNewHotelManagerSpreadsheet')
    .addItem('Cài lịch tự động', 'setupHotelTriggers')
    .addToUi();
}

function showHotelManager() {
  SpreadsheetApp.getUi().showModalDialog(
    HtmlService.createTemplateFromFile('Index').evaluate().setWidth(1500).setHeight(900),
    'Hotel Manager Pro 3.1.1'
  );
}

function createNewHotelManagerSpreadsheet() {
  const name = 'HOTEL MANAGER PRO 3 - ' + Utilities.formatDate(new Date(), HMS.TZ, 'yyyyMMdd-HHmm');
  const ss = SpreadsheetApp.create(name);
  PropertiesService.getScriptProperties().setProperty('HMS3_SPREADSHEET_ID', ss.getId());
  setupHotelManager_();
  const first = ss.getSheetByName('Sheet1');
  if (first && ss.getSheets().length > 1 && first.getLastRow() === 0) ss.deleteSheet(first);
  try { SpreadsheetApp.getUi().alert('Đã tạo bảng tính mới:\n' + ss.getUrl()); } catch (ignore) {}
  return { ok: true, spreadsheetId: ss.getId(), url: ss.getUrl() };
}

function setupHotelManager() {
  const active = SpreadsheetApp.getActiveSpreadsheet();
  if (active) PropertiesService.getScriptProperties().setProperty('HMS3_SPREADSHEET_ID', active.getId());
  setupHotelManager_();
  return 'Đã hoàn thiện cấu trúc Hotel Manager Pro ' + HMS.VERSION + '.';
}

function setupHotelManager_() {
  const ss = hmsSpreadsheet_();
  Object.keys(HMS.SHEETS).forEach(function (key) {
    const name = HMS.SHEETS[key];
    ensureHmsSheet_(ss, name, HMS.HEADERS[name]);
  });
  seedHmsData_(ss);
  hmsUpsert_(HMS.SHEETS.SETTINGS, 'KHOA', 'PHIEN_BAN', {
    KHOA: 'PHIEN_BAN', GIA_TRI: HMS.VERSION, NHOM: 'Hệ thống', MO_TA: 'Phiên bản hiện tại'
  });
  ensureHmsFinanceSecurity_();
  formatHmsSheets_(ss);
  PropertiesService.getScriptProperties().setProperty('HMS3_VERSION', HMS.VERSION);
  SpreadsheetApp.flush();
}

/**
 * Kiểm tra nhẹ trước khi tải giao diện. Chỉ chạy setup đầy đủ nếu thực sự thiếu
 * trang tính; không định dạng lại 21 trang ở mỗi lần mở Web App.
 */
function hmsEnsureBootstrapReady_() {
  const ss = hmsSpreadsheet_();
  const existing = {};
  ss.getSheets().forEach(function (sheet) { existing[sheet.getName()] = true; });
  const missing = Object.keys(HMS.SHEETS).map(function (key) { return HMS.SHEETS[key]; })
    .filter(function (name) { return !existing[name]; });
  if (missing.length) {
    setupHotelManager_();
    return hmsSpreadsheet_();
  }
  const props = PropertiesService.getScriptProperties();
  if (props.getProperty('HMS3_VERSION') !== HMS.VERSION) {
    hmsUpsert_(HMS.SHEETS.SETTINGS, 'KHOA', 'PHIEN_BAN', {
      KHOA: 'PHIEN_BAN', GIA_TRI: HMS.VERSION, NHOM: 'Hệ thống', MO_TA: 'Phiên bản hiện tại'
    });
    ensureHmsFinanceSecurity_();
    props.setProperty('HMS3_VERSION', HMS.VERSION);
  }
  return ss;
}

/**
 * Bộ v3 là bộ mới độc lập. Hàm setup chỉ tạo/hoàn thiện cấu trúc hiện hành,
 * không đọc hoặc chuyển đổi dữ liệu của các phiên bản trước.
 */

function ensureHmsSheet_(ss, name, headers) {
  let sheet = ss.getSheetByName(name);
  if (!sheet) sheet = ss.insertSheet(name);
  const width = Math.max(sheet.getLastColumn(), headers.length, 1);
  const current = sheet.getRange(HMS.HEADER_ROW, 1, 1, width).getDisplayValues()[0].map(String);
  let headersChanged = false;
  headers.forEach(function (header) {
    if (current.indexOf(header) < 0) {
      const emptyIndex = current.indexOf('');
      const next = emptyIndex >= 0 ? emptyIndex + 1 : current.length + 1;
      current[next - 1] = header;
      headersChanged = true;
    }
  });
  if (headersChanged) {
    sheet.getRange(HMS.HEADER_ROW, 1, 1, current.length).setValues([current]);
    hmsInvalidate_(name, true);
  }
  if (!sheet.getRange('A1').getValue()) sheet.getRange('A1').setValue(name.replace(/_/g, ' '));
  sheet.setFrozenRows(HMS.HEADER_ROW);
  return sheet;
}

function seedHmsData_(ss) {
  seedIfEmpty_(ss, HMS.SHEETS.GUIDE, [
    [1, 'Cài đặt ban đầu', 'Nhập thông tin khách sạn, giờ nhận/trả phòng, thuế và mẫu hóa đơn.', 'Chỉ thay đổi cột GIA_TRI.'],
    [2, 'Khai báo phòng và bảng giá', 'Kiểm tra DM_PHONG, BANG_GIA_PHONG và trạng thái hoạt động.', 'Mỗi phòng được kinh doanh nguyên phòng.'],
    [3, 'Đặt phòng', 'Chọn thời gian, một hoặc nhiều phòng, khách, giá và tổng tiền cọc; hệ thống chặn trùng lịch.', 'Mỗi phòng là một phiếu cùng mã nhóm; cọc được phân bổ, không nhân đôi.'],
    [4, 'Nhận phòng', 'Xác nhận thời gian thực tế; có thể mở phòng ngay cho khách vãng lai.', 'Đơn giá được chụp tại thời điểm nhận phòng.'],
    [5, 'Trong thời gian lưu trú', 'Thêm đồ giải khát/dịch vụ, đổi phòng hoặc gia hạn nếu còn phòng.', 'Phát sinh theo dõi tồn sẽ tự trừ kho.'],
    [6, 'Trả phòng', 'Chốt giờ trả, số đêm, tiền phòng và chuyển sang hóa đơn.', 'Phòng tự chuyển Chờ vệ sinh.'],
    [7, 'Thanh toán', 'Kiểm tra dịch vụ, phụ thu, giảm tiền, thuế, cọc; có thể thu nhiều lần.', 'Chỉ hóa đơn đủ tiền mới ghi doanh thu.'],
    [8, 'Buồng phòng và bảo trì', 'Hoàn tất vệ sinh để mở bán; xử lý sự cố trước khi mở lại phòng.', 'Mọi thao tác được ghi nhật ký.'],
    [9, 'Báo cáo', 'Mở khóa Tài chính rồi lọc doanh thu, thực thu và công nợ theo khoảng ngày.', 'PIN ban đầu 2468; phải đổi ngay sau khi cài đặt.']
  ]);

  seedIfEmpty_(ss, HMS.SHEETS.SETTINGS, [
    ['TEN_KHACH_SAN', 'KHÁCH SẠN MẪU', 'Thông tin chung', 'Tên hiển thị trên phần mềm và hóa đơn'],
    ['DIA_CHI', '', 'Thông tin chung', 'Địa chỉ'],
    ['DIEN_THOAI', '', 'Thông tin chung', 'Điện thoại'],
    ['EMAIL', '', 'Thông tin chung', 'Email'],
    ['MA_SO_THUE', '', 'Thông tin chung', 'Mã số thuế'],
    ['LOGO_URL', '', 'Nhận diện', 'Đường dẫn logo công khai'],
    ['GIO_NHAN_PHONG', '14:00', 'Vận hành', 'Giờ nhận phòng chuẩn'],
    ['GIO_TRA_PHONG', '12:00', 'Vận hành', 'Giờ trả phòng chuẩn'],
    ['TIEN_TE', 'VND', 'Tài chính', 'Đơn vị tiền tệ'],
    ['THUE_GTGT_MAC_DINH', 0, 'Tài chính', 'Tỷ lệ thuế, ví dụ 0.08'],
    ['PHI_DICH_VU_MAC_DINH', 0, 'Tài chính', 'Tỷ lệ phí dịch vụ, ví dụ 0.05'],
    ['KHOA_TAI_CHINH', true, 'Bảo mật tài chính', 'Yêu cầu PIN khi mở báo cáo tài chính'],
    ['PHIEN_TAI_CHINH_PHUT', 30, 'Bảo mật tài chính', 'Số phút duy trì phiên đã mở khóa'],
    ['SO_LAN_SAI_TOI_DA', 5, 'Bảo mật tài chính', 'Số lần nhập sai trước khi tạm khóa'],
    ['KHOA_TAM_PHUT', 15, 'Bảo mật tài chính', 'Số phút tạm khóa khi nhập sai quá số lần'],
    ['TIEU_DE_HOA_DON', 'HÓA ĐƠN THANH TOÁN', 'Hóa đơn', 'Tiêu đề hóa đơn'],
    ['LOI_CAM_ON', 'Cảm ơn Quý khách và hẹn gặp lại!', 'Hóa đơn', 'Dòng cuối hóa đơn'],
    ['TIEN_TO_DAT_PHONG', 'DP', 'Mã chứng từ', 'Tiền tố phiếu đặt'],
    ['TIEN_TO_HOA_DON', 'HD', 'Mã chứng từ', 'Tiền tố hóa đơn'],
    ['PHIEN_BAN', HMS.VERSION, 'Hệ thống', 'Phiên bản hiện tại']
  ]);

  seedIfEmpty_(ss, HMS.SHEETS.RATES, [
    ['GIA_DON', 'Phòng đơn', 'Giá phòng đơn', 500000, 550000, new Date(2025, 0, 1), '', true, 1, new Date()],
    ['GIA_DOI', 'Phòng đôi', 'Giá phòng đôi', 800000, 900000, new Date(2025, 0, 1), '', true, 1, new Date()],
    ['GIA_GIA_DINH', 'Phòng gia đình', 'Giá phòng gia đình', 1200000, 1350000, new Date(2025, 0, 1), '', true, 1, new Date()]
  ]);

  seedIfEmpty_(ss, HMS.SHEETS.SERVICES, [
    ['NUOC_500', 'Đồ giải khát', 'Nước tinh khiết 500 ml', 'Chai', 10000, true, 20, true, 1, new Date(), 5000],
    ['NUOC_1500', 'Đồ giải khát', 'Nước tinh khiết 1,5 lít', 'Chai', 20000, true, 10, true, 2, new Date(), 10000],
    ['NUOC_NGOT', 'Đồ giải khát', 'Nước ngọt', 'Lon', 15000, true, 12, true, 3, new Date(), 8000],
    ['NUOC_TRAI_CAY', 'Đồ giải khát', 'Nước trái cây', 'Chai', 25000, true, 8, true, 4, new Date(), 14000],
    ['GIAT_UI', 'Dịch vụ', 'Giặt ủi', 'Lần', 50000, false, 0, true, 10, new Date(), 0],
    ['AN_SANG', 'Dịch vụ', 'Ăn sáng', 'Suất', 80000, false, 0, true, 11, new Date(), 0],
    ['TRA_MUON', 'Phụ thu', 'Phụ thu trả phòng muộn', 'Lần', 200000, false, 0, true, 20, new Date(), 0]
  ]);

  const roomRows = [];
  for (let i = 1; i <= 20; i++) {
    const type = i % 5 === 0 ? 'Phòng gia đình' : (i % 2 === 0 ? 'Phòng đôi' : 'Phòng đơn');
    roomRows.push(['P' + ('0' + i).slice(-2), 'Phòng ' + i, Math.ceil(i / 5), type, type === 'Phòng đơn' ? 1 : (type === 'Phòng đôi' ? 2 : 4), 'Phòng trống', true, '']);
  }
  seedIfEmpty_(ss, HMS.SHEETS.ROOMS, roomRows);

  const stockSheet = ss.getSheetByName(HMS.SHEETS.STOCK);
  if (!hasHmsData_(stockSheet)) {
    const tracked = hmsObjects_(HMS.SHEETS.SERVICES).filter(function (x) { return hmsBool_(x.THEO_DOI_TON); });
    if (tracked.length) stockSheet.getRange(HMS.DATA_ROW, 1, tracked.length, 10).setValues(tracked.map(function (x) {
      return [x.MA_DICH_VU, x.TEN_DICH_VU, x.DON_VI, 100, 0, 0, 100, Number(x.TON_TOI_THIEU || 0), 'Đủ hàng', new Date()];
    }));
  }
}

function seedIfEmpty_(ss, sheetName, rows) {
  const sheet = ss.getSheetByName(sheetName);
  if (!sheet || hasHmsData_(sheet) || !rows.length) return;
  sheet.getRange(HMS.DATA_ROW, 1, rows.length, rows[0].length).setValues(rows);
}

function hasHmsData_(sheet) {
  if (!sheet || sheet.getLastRow() < HMS.DATA_ROW) return false;
  return sheet.getRange(HMS.DATA_ROW, 1, sheet.getLastRow() - HMS.DATA_ROW + 1, 1).getDisplayValues().some(function (r) { return String(r[0]).trim(); });
}

function formatHmsSheets_(ss) {
  const navy = '#183B56';
  Object.keys(HMS.SHEETS).forEach(function (key) {
    const sheet = ss.getSheetByName(HMS.SHEETS[key]);
    if (!sheet) return;
    const cols = HMS.HEADERS[HMS.SHEETS[key]].length;
    sheet.getRange(1, 1, 1, Math.max(1, cols)).setBackground(navy).setFontColor('#FFFFFF').setFontWeight('bold').setFontSize(14);
    sheet.getRange(HMS.HEADER_ROW, 1, 1, cols).setBackground('#DCE6F1').setFontWeight('bold').setWrap(true);
    sheet.autoResizeColumns(1, Math.min(cols, 12));
  });
  applyHmsValidations_(ss);
}

function applyHmsValidations_(ss) {
  const list = function (values) { return SpreadsheetApp.newDataValidation().requireValueInList(values, true).setAllowInvalid(false).build(); };
  const room = ss.getSheetByName(HMS.SHEETS.ROOMS);
  room.getRange(HMS.DATA_ROW, 4, 1000, 1).setDataValidation(list(['Phòng đơn', 'Phòng đôi', 'Phòng gia đình']));
  room.getRange(HMS.DATA_ROW, 6, 1000, 1).setDataValidation(list(HMS.ROOM_STATUSES.slice()));
  const booking = ss.getSheetByName(HMS.SHEETS.BOOKINGS);
  booking.getRange(HMS.DATA_ROW, 15, 2000, 1).setDataValidation(list(['Chờ xác nhận', 'Đã xác nhận', 'Đã nhận phòng', 'Đã hủy', 'Không đến', 'Đã trả phòng']));
  const invoice = ss.getSheetByName(HMS.SHEETS.INVOICES);
  invoice.getRange(HMS.DATA_ROW, 23, 2000, 1).setDataValidation(list(['Nháp', 'Chờ thanh toán', 'Đã thanh toán', 'Đã hủy']));
  const service = ss.getSheetByName(HMS.SHEETS.SERVICES);
  service.getRange(HMS.DATA_ROW, 2, 1000, 1).setDataValidation(list(['Đồ giải khát', 'Nước uống', 'Dịch vụ', 'Phụ thu']));
}

function setupHotelTriggers() {
  ScriptApp.getProjectTriggers().forEach(function (trigger) {
    if (trigger.getHandlerFunction() === 'hotelMorningRoutine') ScriptApp.deleteTrigger(trigger);
  });
  ScriptApp.newTrigger('hotelMorningRoutine').timeBased().everyDays(1).atHour(7).create();
  return 'Đã cài lịch kiểm tra đầu ngày lúc 07:00.';
}

function hotelMorningRoutine() {
  const today = hmsDateKey_(new Date());
  hmsObjects_(HMS.SHEETS.BOOKINGS).forEach(function (b) {
    if (['Chờ xác nhận', 'Đã xác nhận'].indexOf(String(b.TRANG_THAI)) >= 0 && hmsDateKey_(b.NHAN_DU_KIEN) < today) {
      hmsUpdate_(HMS.SHEETS.BOOKINGS, b._rowNumber, { TRANG_THAI: 'Không đến' });
      hmsLog_('Tự động đánh dấu không đến', 'Đặt phòng', b.MA_DAT_PHONG, b.MA_PHONG);
    }
  });
  hmsRefreshAllRoomStatuses_();
}

function runHotelHealthCheck() {
  setupHotelManager_();
  const ss = hmsSpreadsheet_();
  const missing = Object.keys(HMS.SHEETS).map(function (k) { return HMS.SHEETS[k]; }).filter(function (n) { return !ss.getSheetByName(n); });
  const duplicateRooms = hmsDuplicates_(hmsObjects_(HMS.SHEETS.ROOMS).map(function (r) { return String(r.MA_PHONG || ''); }).filter(String));
  const duplicateBookings = hmsDuplicates_(hmsObjects_(HMS.SHEETS.BOOKINGS).map(function (r) { return String(r.MA_DAT_PHONG || ''); }).filter(String));
  const ok = !missing.length && !duplicateRooms.length && !duplicateBookings.length;
  const result = { ok: ok, version: HMS.VERSION, spreadsheetId: ss.getId(), missingSheets: missing, duplicateRooms: duplicateRooms, duplicateBookings: duplicateBookings, checkedAt: hmsDateTimeText_(new Date()) };
  try { SpreadsheetApp.getUi().alert(ok ? 'Hệ thống hợp lệ.' : JSON.stringify(result, null, 2)); } catch (ignore) {}
  return result;
}
